"""EdgeVision 后端应用包。"""
