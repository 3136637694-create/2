"""目标检测：Detector 抽象 + ONNX YOLO 推理 + 无模型时 Demo 回退。

- 模型文件（models/yolov8n.onnx）存在时使用 onnxruntime 真实推理
- 缺失时回退 DemoDetector（基于图像颜色特征合成目标），保证流水线可独立验证
- 输出统一为像素坐标 bbox（x1, y1, x2, y2）
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from ..config import settings
from ..models import DetClass

# COCO 类别 -> 业务类别映射
_COCO_TO_CLS: dict[int, DetClass] = {0: "person", 2: "vehicle"}


@dataclass
class Box:
    """单个检测框（像素坐标 x1, y1, x2, y2）。"""

    cls: DetClass
    confidence: float
    bbox: tuple[float, float, float, float]


class Detector(ABC):
    """检测器抽象：业务只依赖本接口，模型实现可替换。"""

    @abstractmethod
    def detect(self, frame: np.ndarray) -> list[Box]:
        """对单帧 BGR 图像执行目标检测。"""

    def close(self) -> None:
        """释放资源（默认无操作）。"""


# ============ ONNX YOLO 推理 ============

class OnnxYoloDetector(Detector):
    """YOLOv8n ONNX 推理。输出形状 (1, 84, 8400)：4 框坐标 + 80 类别得分。"""

    CONF_THRESHOLD = 0.25
    IOU_THRESHOLD = 0.45
    INPUT_SIZE = 640

    def __init__(self, model_path: str | Path) -> None:
        import onnxruntime as ort

        self._session = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
        self._input_name = self._session.get_inputs()[0].name

    def detect(self, frame: np.ndarray) -> list[Box]:
        h, w = frame.shape[:2]
        # letterbox 缩放 + 预处理
        img, (ratio, pad_x, pad_y) = _letterbox(frame, self.INPUT_SIZE)
        blob = img.transpose(2, 0, 1)[None].astype(np.float32) / 255.0
        out = self._session.run(None, {self._input_name: blob})[0]   # (1, 84, 8400)
        preds = out[0].T                                             # (8400, 84)

        scores = preds[:, 4:]
        cls_ids = scores.argmax(axis=1)
        confs = scores[np.arange(len(scores)), cls_ids]
        mask = confs >= self.CONF_THRESHOLD
        preds, cls_ids, confs = preds[mask], cls_ids[mask], confs[mask]

        # NMS（按置信度降序）
        keep = _nms(preds, confs, self.IOU_THRESHOLD)

        boxes: list[Box] = []
        for i in keep:
            cx, cy, bw, bh = preds[i][:4]
            x1 = (cx - bw / 2 - pad_x) / ratio
            y1 = (cy - bh / 2 - pad_y) / ratio
            x2 = (cx + bw / 2 - pad_x) / ratio
            y2 = (cy + bh / 2 - pad_y) / ratio
            # 裁剪回帧内并归一化
            x1, y1 = max(0.0, x1), max(0.0, y1)
            x2, y2 = min(w, x2), min(h, y2)
            if x2 - x1 < 2 or y2 - y1 < 2:
                continue
            cls: DetClass = _COCO_TO_CLS.get(int(cls_ids[i]), "object")
            boxes.append(Box(cls, float(confs[i]), (float(x1), float(y1), float(x2), float(y2))))
        return boxes

    def close(self) -> None:
        self._session = None  # type: ignore[assignment]


def _letterbox(img: np.ndarray, size: int) -> tuple[np.ndarray, tuple[float, float, float]]:
    """等比缩放 + 灰边填充，返回 (处理图, (ratio, pad_x, pad_y))。"""
    h, w = img.shape[:2]
    ratio = min(size / w, size / h)
    nw, nh = int(w * ratio), int(h * ratio)
    resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    canvas = np.full((size, size, 3), 114, dtype=np.uint8)
    pad_x = (size - nw) / 2
    pad_y = (size - nh) / 2
    canvas[int(pad_y): int(pad_y) + nh, int(pad_x): int(pad_x) + nw] = resized
    return canvas, (ratio, pad_x, pad_y)


def _nms(preds: np.ndarray, confs: np.ndarray, iou_thr: float) -> list[int]:
    """非极大值抑制（NMS）。"""
    order = confs.argsort()[::-1]
    keep: list[int] = []
    while order.size:
        i = order[0]
        keep.append(i)
        if order.size == 1:
            break
        rest = order[1:]
        iou = _iou(preds[i], preds[rest])
        order = rest[iou < iou_thr]
    return keep


def _iou(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ax1, ay1, ax2, ay2 = a[0], a[1], a[2], a[3]
    bx1, by1, bx2, by2 = b[:, 0], b[:, 1], b[:, 2], b[:, 3]
    inter = np.maximum(0, np.minimum(ax2, bx2) - np.maximum(ax1, bx1)) * \
            np.maximum(0, np.minimum(ay2, by2) - np.maximum(ay1, by1))
    area_a = (ax2 - ax1) * (ay2 - ay1)
    area_b = (bx2 - bx1) * (by2 - by1)
    return inter / (area_a + area_b - inter + 1e-6)


# ============ Demo 回退检测器 ============

class DemoDetector(Detector):
    """无模型回退：通过颜色阈值识别画面中的目标（配合 SimulatedSource 绿色圆形）。

    - 仅用于演示/联调，保证无模型环境下流水线完整运行
    """

    def detect(self, frame: np.ndarray) -> list[Box]:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (35, 60, 60), (85, 255, 255))   # 绿色目标
        mask = cv2.erode(mask, None, iterations=1)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        boxes: list[Box] = []
        for c in contours:
            if cv2.contourArea(c) < 120:   # 过滤噪点
                continue
            x, y, w, h = cv2.boundingRect(c)
            conf = float(min(0.99, 0.72 + cv2.contourArea(c) / 20000.0))
            boxes.append(Box("person", conf, (float(x), float(y), float(x + w), float(y + h))))
        return boxes


def create_detector(model_path: str | Path | None = None) -> Detector:
    """工厂：模型文件存在 -> ONNX 推理；否则 Demo 回退。"""
    path = Path(model_path or settings.model_path)
    if path.is_file():
        return OnnxYoloDetector(path)
    return DemoDetector()
