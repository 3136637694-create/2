"""事件状态机：基于跟踪结果识别异常事件。

规则（均为规则状态机 + 冷却，避免重复告警）：
- region_intrusion  区域闯入：目标中心进入禁区 -> 触发
- people_gathering   人员聚集：区域内 person 目标数持续超过阈值 -> 触发
- left_object        遗留物：object 类目标长时间静止 -> 触发
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

import numpy as np

from ..models import AlertEvent, EventLevel, EventTarget, EventType
from .sort import Track

# 禁区（归一化坐标 x1, y1, x2, y2）
INTRUSION_ZONE = (0.15, 0.35, 0.85, 0.75)
# 聚集判定区域（归一化坐标，全画面内的子区域）
GATHER_ZONE = (0.0, 0.0, 1.0, 1.0)
GATHER_MIN_PEOPLE = 3          # 聚集人数阈值
GATHER_HOLD_SECONDS = 2.0      # 持续时长阈值
GATHER_COOLDOWN = 30.0
INTRUSION_COOLDOWN = 30.0
LEFT_OBJECT_COOLDOWN = 60.0
LEFT_OBJECT_HOLD_FRAMES = 30   # 静止帧数阈值
LEFT_OBJECT_MOVE_PX = 6.0      # 帧间位移低于该值视为静止


def _norm(bbox: tuple[float, float, float, float], shape: tuple[int, int]) -> tuple[float, float, float, float]:
    """像素 bbox -> 归一化 bbox。"""
    h, w = shape
    return (bbox[0] / w, bbox[1] / h, bbox[2] / w, bbox[3] / h)


class EventEngine:
    """事件分析引擎（每路摄像头独立实例）。"""

    def __init__(self, camera_id: int, camera_name: str) -> None:
        self.camera_id = camera_id
        self.camera_name = camera_name
        self._cooldowns: dict[tuple[EventType, int], float] = {}
        self._gather_start: float | None = None
        self._static: dict[int, int] = {}     # track_id -> 连续静止帧数
        self._last_pos: dict[int, tuple[float, float]] = {}

    def _in_zone(self, bbox: tuple[float, float, float, float], zone: tuple[float, float, float, float],
                 shape: tuple[int, int]) -> bool:
        nb = _norm(bbox, shape)
        cx, cy = (nb[0] + nb[2]) / 2, (nb[1] + nb[3]) / 2
        return zone[0] <= cx <= zone[2] and zone[1] <= cy <= zone[3]

    def _can_trigger(self, etype: EventType, key: int) -> bool:
        now = time.time()
        last = self._cooldowns.get((etype, key), 0.0)
        if now - last < _COOLDOWN_SECS[etype]:
            return False
        self._cooldowns[(etype, key)] = now
        return True

    def _make_event(self, etype: EventType, level: EventLevel, message: str,
                    targets: list[EventTarget]) -> AlertEvent:
        return AlertEvent(
            camera_id=self.camera_id,
            camera_name=self.camera_name,
            type=etype,
            level=level,
            message=message,
            targets=targets,
            ts=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
        )

    def update(self, tracked: list[tuple[Track, tuple[float, float, float, float]]],
               frame_shape: tuple[int, int]) -> list[AlertEvent]:
        """处理一帧跟踪结果，返回新触发的事件列表。"""
        events: list[AlertEvent] = []

        # ---- 区域闯入 ----
        for t, bbox in tracked:
            if t.box_cls in ("person", "vehicle") and self._in_zone(bbox, INTRUSION_ZONE, frame_shape):
                if self._can_trigger("region_intrusion", t.track_id):
                    events.append(self._make_event(
                        "region_intrusion", "critical",
                        f"目标 #{t.track_id} 闯入禁止区域",
                        [EventTarget(track_id=t.track_id, cls=t.box_cls, confidence=t.confidence)],
                    ))

        # ---- 人员聚集 ----
        in_zone_people = [t for t, b in tracked if t.box_cls == "person" and self._in_zone(b, GATHER_ZONE, frame_shape)]
        if len(in_zone_people) >= GATHER_MIN_PEOPLE:
            if self._gather_start is None:
                self._gather_start = time.time()
            elif time.time() - self._gather_start >= GATHER_HOLD_SECONDS:
                if self._can_trigger("people_gathering", 0):
                    targets = [
                        EventTarget(track_id=t.track_id, cls=t.box_cls, confidence=t.confidence)
                        for t in in_zone_people
                    ]
                    events.append(self._make_event(
                        "people_gathering", "warning",
                        f"检测到 {len(in_zone_people)} 人聚集",
                        targets,
                    ))
        else:
            self._gather_start = None

        # ---- 遗留物（object 类静止目标） ----
        for t, bbox in tracked:
            if t.box_cls != "object":
                continue
            cx, cy = (bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2
            prev = self._last_pos.get(t.track_id)
            if prev is not None and abs(cx - prev[0]) < LEFT_OBJECT_MOVE_PX and abs(cy - prev[1]) < LEFT_OBJECT_MOVE_PX:
                self._static[t.track_id] = self._static.get(t.track_id, 0) + 1
            else:
                self._static[t.track_id] = 0
            self._last_pos[t.track_id] = (cx, cy)
            if self._static[t.track_id] >= LEFT_OBJECT_HOLD_FRAMES:
                if self._can_trigger("left_object", t.track_id):
                    events.append(self._make_event(
                        "left_object", "warning",
                        f"检测到遗留物 #{t.track_id}",
                        [EventTarget(track_id=t.track_id, cls=t.box_cls, confidence=t.confidence)],
                    ))

        return events


# 冷却时长表（供 _can_trigger 使用）
_COOLDOWN_SECS: dict[EventType, float] = {
    "region_intrusion": INTRUSION_COOLDOWN,
    "people_gathering": GATHER_COOLDOWN,
    "left_object": LEFT_OBJECT_COOLDOWN,
}
