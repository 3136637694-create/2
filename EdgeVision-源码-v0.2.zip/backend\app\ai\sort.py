"""SORT（Simple Online and Realtime Tracking）多目标跟踪。

- 卡尔曼滤波（常速模型）预测目标状态
- IoU 成本矩阵 + 匈牙利算法做检测-轨迹关联
- 为每个目标分配稳定 track_id，记录轨迹
- 无 scipy 依赖（匈牙利算法内置实现）
"""

from __future__ import annotations

import numpy as np

from .detector import Box


def _iou(bb_a: tuple[float, float, float, float], bb_b: tuple[float, float, float, float]) -> float:
    a_x1, a_y1, a_x2, a_y2 = bb_a
    b_x1, b_y1, b_x2, b_y2 = bb_b
    inter = max(0.0, min(a_x2, b_x2) - max(a_x1, b_x1)) * max(0.0, min(a_y2, b_y2) - max(a_y1, b_y1))
    area_a = (a_x2 - a_x1) * (a_y2 - a_y1)
    area_b = (b_x2 - b_x1) * (b_y2 - b_y1)
    return inter / (area_a + area_b - inter + 1e-6)


def _hungarian(cost: np.ndarray) -> list[tuple[int, int]]:
    """最小化分配问题的匈牙利算法（emaxx 1-indexed 实现，pad 成方阵）。

    返回 (行, 列) 有效匹配对（0-indexed）。
    """
    n_rows, n_cols = cost.shape
    n = max(n_rows, n_cols)
    big = cost.max() + 1.0
    a = np.full((n + 1, n + 1), big)          # 1-indexed，pad 用大代价
    a[1:n_rows + 1, 1:n_cols + 1] = cost

    u = np.zeros(n + 1)
    v = np.zeros(n + 1)
    p = np.zeros(n + 1, dtype=int)            # p[j] = 匹配到列 j 的行（0 表示未匹配）
    way = np.zeros(n + 1, dtype=int)

    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = np.full(n + 1, np.inf)
        used = np.zeros(n + 1, dtype=bool)
        while True:
            used[j0] = True
            i0, delta = p[j0], np.inf
            j1 = 0
            for j in range(1, n + 1):
                if not used[j]:
                    cur = a[i0, j] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j], way[j] = cur, j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while j0 != 0:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1

    pairs = [
        (int(p[j]) - 1, int(j) - 1)
        for j in range(1, n + 1)
        if p[j] != 0 and p[j] <= n_rows and j <= n_cols
    ]
    return pairs


class Track:
    """单个轨迹：卡尔曼状态 + 存活统计。"""

    def __init__(self, track_id: int, bbox: tuple[float, float, float, float], box_cls: str, confidence: float) -> None:
        self.track_id = track_id
        self.box_cls = box_cls
        self.confidence = confidence
        self.hits = 1
        self.time_since_update = 0
        self.trajectory: list[tuple[float, float]] = []   # 轨迹点（中心），供可视化

        # 状态 [cx, cy, s(面积), r(宽高比), vx, vy, vs] 常速模型
        x1, y1, x2, y2 = bbox
        w, h = x2 - x1, y2 - y1
        self.kf = np.array([(x1 + x2) / 2, (y1 + y2) / 2, w * h, w / max(h, 1e-6), 0.0, 0.0, 0.0])
        self.P = np.eye(7) * 100.0
        self._process_noise = 1.0
        self._measurement_noise = 1.0

    def predict(self) -> tuple[float, float, float, float]:
        """卡尔曼预测，返回预测 bbox（中心/面积形式）。"""
        F = np.array([
            [1, 0, 0, 0, 1, 0, 0],
            [0, 1, 0, 0, 0, 1, 0],
            [0, 0, 1, 0, 0, 0, 1],
            [0, 0, 0, 1, 0, 0, 0],
            [0, 0, 0, 0, 1, 0, 0],
            [0, 0, 0, 0, 0, 1, 0],
            [0, 0, 0, 0, 0, 0, 1],
        ], dtype=float)
        self.kf = F @ self.kf
        self.P = F @ self.P @ F.T + np.eye(7) * self._process_noise
        self.time_since_update += 1
        return self.get_bbox()

    def update(self, bbox: tuple[float, float, float, float], box_cls: str, confidence: float) -> None:
        """卡尔曼更新。"""
        x1, y1, x2, y2 = bbox
        w, h = x2 - x1, y2 - y1
        z = np.array([(x1 + x2) / 2, (y1 + y2) / 2, w * h, w / max(h, 1e-6)])
        H = np.array([
            [1, 0, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0, 0],
            [0, 0, 0, 1, 0, 0, 0],
        ], dtype=float)
        R = np.eye(4) * self._measurement_noise
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)
        self.kf = self.kf + K @ (z - H @ self.kf)
        self.P = (np.eye(7) - K @ H) @ self.P
        self.hits += 1
        self.time_since_update = 0
        self.box_cls = box_cls
        self.confidence = confidence
        cx, cy = self.kf[0], self.kf[1]
        self.trajectory.append((float(cx), float(cy)))
        if len(self.trajectory) > 30:   # 轨迹仅保留最近 30 点
            self.trajectory.pop(0)

    def get_bbox(self) -> tuple[float, float, float, float]:
        """由状态转 bbox（像素）。"""
        cx, cy, s, r = self.kf[0], self.kf[1], max(self.kf[2], 1.0), max(self.kf[3], 0.01)
        w = np.sqrt(s * r)
        h = s / w
        return (float(cx - w / 2), float(cy - h / 2), float(cx + w / 2), float(cy + h / 2))


class Sort:
    """SORT 跟踪器（每路摄像头独立实例）。"""

    MAX_AGE = 6            # 丢失超过该帧数删除轨迹
    MIN_HITS = 2           # 至少命中次数才输出（抑制虚警）
    IOU_MATCH = 0.25       # 关联阈值

    def __init__(self) -> None:
        self.tracks: list[Track] = []
        self._next_id = 1

    def update(self, dets: list[Box]) -> list[tuple[Track, tuple[float, float, float, float]]]:
        """输入检测列表，输出 (Track, 匹配 bbox) 列表（已过滤未成熟轨迹）。"""
        # 1. 预测所有轨迹
        predicted = {t: t.predict() for t in self.tracks}

        results: list[tuple[Track, tuple[float, float, float, float]]] = []
        matched_dets: set[int] = set()

        if dets and self.tracks:
            # 2. 构建 IoU 成本矩阵并匈牙利匹配
            cost = np.zeros((len(self.tracks), len(dets)))
            for i, t in enumerate(self.tracks):
                for j, d in enumerate(dets):
                    cost[i, j] = 1.0 - _iou(predicted[t], d.bbox)
            for i, j in _hungarian(cost):
                t = self.tracks[i]
                if 1.0 - cost[i, j] >= self.IOU_MATCH:
                    t.update(dets[j].bbox, dets[j].cls, dets[j].confidence)
                    matched_dets.add(j)
                else:
                    t.time_since_update += 1   # 未匹配：标记一次丢失

        # 3. 创建新轨迹（未匹配的检测）
        for j, d in enumerate(dets):
            if j not in matched_dets:
                self.tracks.append(Track(self._next_id, d.bbox, d.cls, d.confidence))
                self._next_id += 1

        # 4. 清理过期轨迹，收集成熟结果
        alive: list[Track] = []
        for t in self.tracks:
            if t.time_since_update > self.MAX_AGE:
                continue
            alive.append(t)
            if t.hits >= self.MIN_HITS and t.time_since_update == 0:
                results.append((t, t.get_bbox()))
        self.tracks = alive
        return results
