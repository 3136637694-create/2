"""对外服务接口包：REST 路由 + WebSocket + MJPEG 流。"""

from fastapi import APIRouter

from .routes_cameras import router as cameras_router
from .routes_events import router as events_router
from .routes_metrics import router as metrics_router

# /api 聚合路由
api_router = APIRouter(prefix="/api")
api_router.include_router(cameras_router)
api_router.include_router(events_router)
api_router.include_router(metrics_router)
