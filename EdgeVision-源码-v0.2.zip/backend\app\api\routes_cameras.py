"""摄像头 REST 路由：GET/POST /api/cameras、PUT/DELETE /api/cameras/{id}。

- 增删改联动运行时：新增自动启动流水线，更新自动重启，删除自动停止
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Response, status

from ..manager import pipeline_manager
from ..models import CameraCreate, CameraInfo, CameraUpdate
from ..repositories import cameras as repo

router = APIRouter(tags=["摄像头管理"])


@router.get("/cameras", response_model=list[CameraInfo])
def list_cameras() -> list[CameraInfo]:
    """获取全部摄像头配置。"""
    return repo.list()


@router.post("/cameras", response_model=CameraInfo, status_code=status.HTTP_201_CREATED)
def create_camera(payload: CameraCreate) -> CameraInfo:
    """新增摄像头并启动流水线。"""
    cam = repo.create(payload)
    pipeline_manager.start_camera(cam.id)
    return cam


@router.put("/cameras/{camera_id}", response_model=CameraInfo)
def update_camera(camera_id: int, payload: CameraUpdate) -> CameraInfo:
    """更新摄像头配置；源地址/帧率变化时重启流水线。"""
    cam = repo.update(camera_id, payload)
    if cam is None:
        raise HTTPException(status_code=404, detail="摄像头不存在")
    pipe = pipeline_manager.get_pipeline(camera_id)
    if cam.enabled:
        if pipe is None:
            # 配置了但无流水线（如重启后丢失）：无条件重建
            pipeline_manager.start_camera(camera_id)
        elif (
            (payload.source is not None and payload.source != pipe.source) or
            (payload.fps is not None and int(payload.fps) != pipe.target_fps)
        ):
            # 源或帧率变更需重启流水线生效
            pipeline_manager.restart_camera(camera_id)
    elif pipe is not None:
        # 禁用：停止流水线
        pipeline_manager.stop_camera(camera_id)
    return cam


@router.delete("/cameras/{camera_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_camera(camera_id: int) -> Response:
    """删除摄像头并停止其流水线。"""
    if not repo.delete(camera_id):
        raise HTTPException(status_code=404, detail="摄像头不存在")
    pipeline_manager.stop_camera(camera_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
