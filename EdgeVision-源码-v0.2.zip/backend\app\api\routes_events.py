"""告警事件 REST 路由：GET /api/events 历史告警分页查询。"""

from __future__ import annotations

from fastapi import APIRouter, Query

from ..models import AlertEvent
from ..repositories import events as repo

router = APIRouter(tags=["告警事件"])


@router.get("/events")
def list_events(
    type: str | None = Query(default=None, alias="type"),
    level: str | None = Query(default=None),
    camera_id: int | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=200),
) -> dict:
    """按 类型/等级/摄像头 过滤 + 分页查询历史告警。"""
    items, total = repo.list(
        event_type=type,
        level=level,
        camera_id=camera_id,
        page=page,
        page_size=page_size,
    )
    return {"items": [e.model_dump(by_alias=True) for e in items], "total": total}
