"""系统指标 REST 路由：GET /api/metrics 历史指标、GET /api/system/stats 概览。"""

from __future__ import annotations

import time

from fastapi import APIRouter

from ..config import settings
from ..models import SystemStats
from ..repositories import metrics as metric_repo
from ..repositories import stats as stats_repo

# 进程启动时刻（用于 uptime 统计）
_PROC_START = time.time()

router = APIRouter(tags=["系统指标"])


@router.get("/metrics")
def get_metrics() -> list[dict]:
    """最近 60 条指标序列（按时间升序，供折线图）。"""
    return [m.model_dump(by_alias=True) for m in metric_repo.recent(60)]


@router.get("/system/stats", response_model=SystemStats)
def get_system_stats() -> SystemStats:
    """系统概览统计。"""
    # 运行时长：进程启动至今
    uptime_sec = int(time.time() - _PROC_START)
    return stats_repo.summary(
        version=settings.version,
        model=settings.model,
        uptime_sec=uptime_sec,
    )
