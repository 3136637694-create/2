"""MJPEG 视频流：GET /stream/{id}，实时输出摄像头画面（供前端 <img> 展示）。"""

from __future__ import annotations

import asyncio

import cv2
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from ..manager import pipeline_manager

router = APIRouter(tags=["视频流"])

_BOUNDARY = b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"
_TAIL = b"\r\n"


async def _frame_gen(camera_id: int):
    """循环读取最新帧并编码为 JPEG 分块输出。"""
    while True:
        pipe = pipeline_manager.get_pipeline(camera_id)
        frame = pipe._capture.latest_frame() if pipe else None
        if frame is not None:
            ok, jpg = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ok:
                yield _BOUNDARY + jpg.tobytes() + _TAIL
        await asyncio.sleep(0.05)


@router.get("/stream/{camera_id}")
async def mjpeg_stream(camera_id: int) -> StreamingResponse:
    if pipeline_manager.get_pipeline(camera_id) is None:
        raise HTTPException(status_code=404, detail="摄像头不存在或未启用")
    return StreamingResponse(
        _frame_gen(camera_id),
        media_type="multipart/x-mixed-replace; boundary=frame",
    )
