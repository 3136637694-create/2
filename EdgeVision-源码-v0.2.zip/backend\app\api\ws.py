"""WebSocket 实时通道：连接管理 + 多订阅者广播 + /ws/monitor 端点。"""

from __future__ import annotations

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter(tags=["实时通道"])


class ConnectionManager:
    """维护所有活动 WebSocket 连接并广播消息。"""

    def __init__(self) -> None:
        self.connections: list[WebSocket] = []

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        self.connections.append(ws)

    def disconnect(self, ws: WebSocket) -> None:
        if ws in self.connections:
            self.connections.remove(ws)

    async def broadcast(self, message: dict) -> None:
        """向所有连接推送 JSON（丢弃失败连接）。"""
        dead: list[WebSocket] = []
        for ws in self.connections:
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws)


ws_manager = ConnectionManager()


@router.websocket("/ws/monitor")
async def monitor_endpoint(ws: WebSocket) -> None:
    """实时推送通道：检测帧 / 告警事件 / 系统指标（见前端 ws.ts 契约）。"""
    await ws_manager.connect(ws)
    try:
        # 持续接收客户端消息（心跳/订阅），直到断开
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(ws)
