"""全局配置：路径、服务参数、采集/推理参数集中管理。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# 项目根目录（backend/ 上级）
ROOT_DIR = Path(__file__).resolve().parent.parent


@dataclass
class Settings:
    # ---- 应用 ----
    app_name: str = "EdgeVision 边缘端实时视觉分析系统"
    version: str = "0.1.0"
    model: str = "YOLOv8n · ONNX Runtime（模型缺失时回退演示检测）"
    host: str = "0.0.0.0"
    port: int = 8000

    # ---- 数据目录 ----
    data_dir: Path = field(default_factory=lambda: ROOT_DIR / "data")
    db_path: Path = field(default_factory=lambda: ROOT_DIR / "data" / "edgevision.db")

    # ---- 模型 ----
    models_dir: Path = field(default_factory=lambda: ROOT_DIR / "models")
    # 模型文件放入 models/ 目录后自动切换真实推理；缺失时回退 DemoDetector 模拟
    model_path: Path = field(default_factory=lambda: ROOT_DIR / "models" / "yolov8n.onnx")

    # ---- 采集流水线 ----
    queue_capacity: int = 100          # 每路摄像头帧队列容量（满丢帧保护）
    target_fps: int = 15               # 采集目标帧率
    rtsp_retry_base: float = 2.0       # 断线重连基础退避秒数
    rtsp_retry_max: float = 60.0       # 断线重连最大退避秒数

    # ---- 指标记录 ----
    metric_interval_s: int = 5         # 系统指标采样间隔（秒）


settings = Settings()

# 确保数据目录存在
settings.data_dir.mkdir(parents=True, exist_ok=True)
settings.models_dir.mkdir(parents=True, exist_ok=True)
