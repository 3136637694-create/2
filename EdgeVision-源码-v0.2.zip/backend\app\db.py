"""SQLite 数据访问层：连接管理、建表、基础 CRUD。

- 单连接 + 线程锁（check_same_thread=False），WAL 模式提升并发读写表现
- 所有 SQL 一律使用参数化占位符（?），防止 SQL 注入
- 业务查询方法将在第 2 步（数据层）补充，此处先完成表结构与连接初始化
"""

from __future__ import annotations

import sqlite3
import threading
from typing import Any

from .config import settings

# 建表 SQL：摄像头 / 告警事件 / 系统指标
_SCHEMA = """
CREATE TABLE IF NOT EXISTS cameras (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    location    TEXT    NOT NULL DEFAULT '',
    source      TEXT    NOT NULL,
    status      TEXT    NOT NULL DEFAULT 'offline',   -- online / offline / reconnecting
    fps         REAL    NOT NULL DEFAULT 0,
    resolution  TEXT    NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    last_seen   TEXT    NOT NULL DEFAULT '',          -- 最近收到帧时间 HH:mm:ss
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    camera_id   INTEGER NOT NULL,
    camera_name TEXT    NOT NULL DEFAULT '',
    type        TEXT    NOT NULL,                     -- region_intrusion / people_gathering / left_object
    level       TEXT    NOT NULL DEFAULT 'info',      -- critical / warning / info
    message     TEXT    NOT NULL DEFAULT '',
    targets     TEXT    NOT NULL DEFAULT '[]',        -- JSON 数组 [{trackId, cls, confidence}]
    ts          TEXT    NOT NULL                      -- ISO 时间
);

CREATE TABLE IF NOT EXISTS metrics (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              REAL    NOT NULL,                 -- epoch 毫秒
    e2e_latency_ms  REAL    NOT NULL DEFAULT 0,
    dropped_frames  INTEGER NOT NULL DEFAULT 0,
    queue_capacity  INTEGER NOT NULL DEFAULT 100,
    queue_usage     REAL    NOT NULL DEFAULT 0,
    fps             REAL    NOT NULL DEFAULT 0,
    detection_ms    REAL    NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_events_camera_id ON events (camera_id);
CREATE INDEX IF NOT EXISTS idx_events_type       ON events (type);
CREATE INDEX IF NOT EXISTS idx_events_ts         ON events (ts);
CREATE INDEX IF NOT EXISTS idx_metrics_ts        ON metrics (ts);
"""


class Database:
    """SQLite 封装：线程安全连接 + 参数化执行辅助。"""

    def __init__(self, db_path: str | None = None) -> None:
        self._path = str(db_path or settings.db_path)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row   # 查询返回 Row（支持 dict(row) 与列名访问）
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")

    def init_schema(self) -> None:
        """初始化表结构与索引（幂等）。"""
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def execute(self, sql: str, params: tuple[Any, ...] = ()) -> int:
        """执行写操作，返回 lastrowid。"""
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return int(cur.lastrowid or 0)

    def query_all(self, sql: str, params: tuple[Any, ...] = ()) -> list[sqlite3.Row]:
        """执行查询，返回 Row 列表。"""
        with self._lock:
            cur = self._conn.execute(sql, params)
            return cur.fetchall()

    def query_one(self, sql: str, params: tuple[Any, ...] = ()) -> sqlite3.Row | None:
        """执行查询，返回单行或 None。"""
        with self._lock:
            cur = self._conn.execute(sql, params)
            return cur.fetchone()

    def close(self) -> None:
        with self._lock:
            self._conn.close()


# 进程级单例
db = Database()
