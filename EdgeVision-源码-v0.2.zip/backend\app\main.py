"""FastAPI 应用入口：CORS、生命周期、路由注册、运行时桥接。"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import api_router
from .api.stream import router as stream_router
from .api.ws import router as ws_router, ws_manager
from .config import settings
from .db import db
from .manager import pipeline_manager
from .metrics import metric_sampler


@asynccontextmanager
async def lifespan(_: FastAPI):
    """应用启动/关闭生命周期：初始化数据库、启动流水线、采样与广播桥接。"""
    db.init_schema()

    loop = asyncio.get_running_loop()

    def bridge(frame) -> None:
        """线程回调 -> 主事件循环广播（线程安全投递）。"""
        payload = frame.model_dump(by_alias=True)
        loop.call_soon_threadsafe(
            lambda: asyncio.create_task(ws_manager.broadcast(payload))
        )

    pipeline_manager.on_detections_frame = bridge
    pipeline_manager.on_event_frame = bridge
    metric_sampler.on_metric = bridge

    pipeline_manager.init()
    metric_sampler.start()
    try:
        yield
    finally:
        metric_sampler.stop()
        pipeline_manager.shutdown()
        db.close()


app = FastAPI(
    title=settings.app_name,
    description="边缘端实时视觉分析系统后端接口。视频采集 → YOLO 目标检测 → SORT 多目标跟踪 → 事件分析 → 实时告警。",
    version=settings.version,
    lifespan=lifespan,
    swagger_ui_parameters={
        "displayLang": "zh-CN",  # Swagger UI 界面语言：中文
        "deepLinking": True,
    },
)

# CORS：允许任意来源，便于前端独立域名部署或本地直接调试
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载业务路由
app.include_router(api_router)        # REST：/api/*
app.include_router(ws_router)         # WebSocket：/ws/monitor
app.include_router(stream_router)     # MJPEG：/stream/{id}


@app.get("/api/health")
def health() -> dict:
    """健康检查端点，用于探活与联调自测。"""
    return {"status": "ok", "app": settings.app_name, "version": settings.version}


@app.get("/")
def root():
    """根路径：重定向到接口文档（Swagger UI）。"""
    from fastapi.responses import RedirectResponse

    return RedirectResponse(url="/docs")
