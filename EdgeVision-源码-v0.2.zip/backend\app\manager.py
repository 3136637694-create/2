"""运行时管理器：按数据库配置启动/停止各摄像头处理流水线。

- 事件：写入数据库 + 广播到 WebSocket
- 检测：限频广播到 WebSocket（0.25s/路），避免消息风暴
- 摄像头增删改：动态启停 / 重启流水线
"""

from __future__ import annotations

import threading
import time

from .config import settings
from .models import AlertEvent, Detection, DetectionFrame, EventFrame
from .pipeline import Pipeline
from .repositories import cameras as camera_repo
from .repositories import events as event_repo

# 检测广播限频（秒/路）
DETECTION_BROADCAST_INTERVAL = 0.25


class PipelineManager:
    """管理所有摄像头的 Pipeline 实例。"""

    def __init__(self) -> None:
        self.pipelines: dict[int, Pipeline] = {}
        self._lock = threading.Lock()
        self.on_detections_frame: callable | None = None   # (DetectionFrame) -> 广播
        self.on_event_frame: callable | None = None        # (EventFrame) -> 广播
        self.on_status_change: callable | None = None      # (camera_id, status) -> 广播
        self._last_broadcast: dict[int, float] = {}

    # ---- 生命周期 ----

    def init(self) -> None:
        """启动所有 enabled 摄像头。"""
        for cam in camera_repo.list():
            if cam.enabled:
                self.start_camera(cam.id)

    def shutdown(self) -> None:
        for pid in list(self.pipelines):
            self.stop_camera(pid)

    # ---- 单路管理 ----

    def start_camera(self, camera_id: int) -> Pipeline | None:
        cam = camera_repo.get(camera_id)
        if cam is None:
            return None
        with self._lock:
            if camera_id in self.pipelines:
                return self.pipelines[camera_id]
            pipe = Pipeline(
                camera_id=camera_id,
                camera_name=cam.name,
                source=cam.source,
                target_fps=int(cam.fps) or 15,
                queue_capacity=settings.queue_capacity,
                status_cb=self._status_cb,
            )
            pipe.on_detections = self._on_detections
            pipe.on_event = self._on_event
            pipe.start()
            self.pipelines[camera_id] = pipe
            return pipe

    def stop_camera(self, camera_id: int) -> None:
        with self._lock:
            pipe = self.pipelines.pop(camera_id, None)
        if pipe is not None:
            pipe.stop()

    def restart_camera(self, camera_id: int) -> None:
        self.stop_camera(camera_id)
        self.start_camera(camera_id)

    def get_pipeline(self, camera_id: int) -> Pipeline | None:
        return self.pipelines.get(camera_id)

    # ---- 回调 ----

    def _status_cb(self, camera_id: int, status: str) -> None:
        camera_repo.set_status(camera_id, status)
        if self.on_status_change:
            try:
                self.on_status_change(camera_id, status)
            except Exception:
                pass

    def _on_detections(self, camera_id: int, items: list[Detection]) -> None:
        # 限频：每路 0.25s 内只广播一次最新检测帧
        now = time.time()
        if now - self._last_broadcast.get(camera_id, 0.0) < DETECTION_BROADCAST_INTERVAL:
            return
        self._last_broadcast[camera_id] = now
        if self.on_detections_frame:
            frame = DetectionFrame(
                kind="detections",
                camera_id=camera_id,
                ts=items[0].ts,
                items=items,
            )
            try:
                self.on_detections_frame(frame)
            except Exception:
                pass

    def _on_event(self, event: AlertEvent) -> None:
        saved = event_repo.create(event)   # 持久化
        if self.on_event_frame:
            try:
                self.on_event_frame(EventFrame(kind="event", event=saved))
            except Exception:
                pass


# 进程级单例
pipeline_manager = PipelineManager()
