"""指标采样：定时汇总各流水线性能指标，写入数据库并广播 WebSocket。"""

from __future__ import annotations

import threading
import time

from .manager import pipeline_manager
from .models import Metric, MetricFrame
from .repositories import metrics as metric_repo


class MetricSampler:
    """周期采样线程。"""

    def __init__(self, interval: float = 5.0) -> None:
        self.interval = interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.on_metric: callable | None = None   # (MetricFrame) -> 广播

    def start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="metric-sampler", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=3)
            self._thread = None

    def _run(self) -> None:
        while not self._stop.wait(self.interval):
            self.sample_once()

    def sample_once(self) -> None:
        """对每路流水线采样一次并入库 / 广播。"""
        for camera_id, pipe in list(pipeline_manager.pipelines.items()):
            snap = pipe.metric_snapshot()
            m = Metric(
                ts=time.time() * 1000.0,
                e2e_latency_ms=snap["e2e_latency_ms"],
                dropped_frames=snap["dropped_frames"],
                queue_capacity=snap["queue_capacity"],
                queue_usage=snap["queue_usage"],
                fps=snap["fps"],
                detection_ms=snap["detection_ms"],
            )
            try:
                metric_repo.insert(m)
            except Exception:
                continue
            if self.on_metric:
                try:
                    self.on_metric(MetricFrame(kind="metric", metric=m))
                except Exception:
                    pass


metric_sampler = MetricSampler()
