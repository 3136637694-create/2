"""Pydantic 数据契约：与前端 frontend/src/types.ts 一一对应。

- 字段名采用 snake_case（直接对齐数据库列），通过 alias 生成 camelCase 响应，
  保证与前端契约（lastSeen / cameraId / e2eLatencyMs 等）严格一致
- 校验接口入参、输出数据，替代零散字典
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

# ---------- 字面量类型 ----------

CameraStatus = Literal["online", "offline", "reconnecting"]
DetClass = Literal["person", "vehicle", "object"]
EventType = Literal["region_intrusion", "people_gathering", "left_object"]
EventLevel = Literal["critical", "warning", "info"]


class ApiModel(BaseModel):
    """基类：DB 列名（snake_case）构造，camelCase 序列化输出。"""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,      # 允许用字段名或别名构造
        from_attributes=True,       # 允许 from ORM/Row
    )


# ---------- 摄像头 ----------

class CameraInfo(ApiModel):
    id: int
    name: str
    location: str = ""
    source: str
    status: CameraStatus = "offline"
    fps: float = 0
    resolution: str = ""
    enabled: bool = True
    last_seen: str = ""             # 最近收到帧时间 HH:mm:ss


class CameraCreate(ApiModel):
    """POST /cameras 请求体（id/status/lastSeen 由系统维护）。"""

    name: str = Field(min_length=1, max_length=64)
    location: str = ""
    source: str = Field(min_length=1)
    fps: float = Field(ge=0, le=120, default=15)
    resolution: str = ""


class CameraUpdate(ApiModel):
    """PUT /cameras/{id} 请求体（部分字段更新）。"""

    name: str | None = Field(default=None, min_length=1, max_length=64)
    location: str | None = None
    source: str | None = Field(default=None, min_length=1)
    fps: float | None = Field(default=None, ge=0, le=120)
    resolution: str | None = None
    enabled: bool | None = None


# ---------- 检测目标 ----------

class Detection(ApiModel):
    id: int
    camera_id: int
    ts: str                          # ISO 时间
    track_id: int                    # SORT 分配的目标跟踪 ID
    cls: DetClass
    confidence: float
    bbox: tuple[float, float, float, float]   # 归一化 [x1, y1, x2, y2]，0~1


class EventTarget(ApiModel):
    track_id: int
    cls: DetClass
    confidence: float


# ---------- 告警事件 ----------

class AlertEvent(ApiModel):
    id: int = 0                      # 创建时由 DB 自增，写入后回读真实 id
    camera_id: int
    camera_name: str = ""
    type: EventType
    level: EventLevel = "info"
    message: str = ""
    targets: list[EventTarget] = Field(default_factory=list)
    ts: str                          # ISO 时间


# ---------- 系统指标 ----------

class Metric(ApiModel):
    id: int | None = None
    ts: float                        # epoch 毫秒
    e2e_latency_ms: float = Field(alias="e2eLatencyMs", default=0)   # 显式别名：to_camel 会误转 e2e
    dropped_frames: int = 0
    queue_capacity: int = 100
    queue_usage: float = 0
    fps: float = 0
    detection_ms: float = 0


class SystemStats(ApiModel):
    cameras_total: int
    cameras_online: int
    events_today: int
    critical_events: int
    avg_latency_ms: float
    dropped_frames: int
    queue_usage: float
    uptime_sec: int
    version: str
    model: str


# ---------- WebSocket 帧（后端 /ws/monitor 推送格式） ----------

class DetectionFrame(ApiModel):
    kind: Literal["detections"]
    camera_id: int
    ts: str
    items: list[Detection]


class EventFrame(ApiModel):
    kind: Literal["event"]
    event: AlertEvent


class MetricFrame(ApiModel):
    kind: Literal["metric"]
    metric: Metric


WsFrame = Annotated[
    Union[DetectionFrame, EventFrame, MetricFrame],
    Field(discriminator="kind"),
]
