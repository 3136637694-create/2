"""视频分析流水线：采集 -> 推理 -> 跟踪 -> 事件分析（每路摄像头一条）。

- 生产-消费解耦：CaptureWorker 生产者 + 本模块消费线程（有界队列满丢帧保护）
- 回调对外输出检测结果与告警事件，由上层（WebSocket 广播 / 入库）接线
- 收集端到端延迟、推理耗时、帧率、丢帧、队列占用等指标快照
"""

from __future__ import annotations

import queue
import threading
import time
from collections.abc import Callable
from datetime import datetime, timezone

import numpy as np

from .ai import Detector, EventEngine, Sort, create_detector
from .config import settings
from .models import Detection, DetClass
from .sources import CaptureWorker

OnDetectionsCb = Callable[[int, list[Detection]], None]
OnEventCb = Callable[[object], None]   # object: AlertEvent


class Pipeline:
    """单路摄像头的完整处理流水线。"""

    def __init__(
        self,
        camera_id: int,
        camera_name: str,
        source: str,
        target_fps: int = 15,
        queue_capacity: int = 100,
        detector: Detector | None = None,
        status_cb: Callable[[int, str], None] | None = None,
    ) -> None:
        self.camera_id = camera_id
        self.camera_name = camera_name
        self.source = source
        self.target_fps = target_fps

        self._capture = CaptureWorker(
            camera_id, source, target_fps=target_fps,
            queue_capacity=queue_capacity, status_cb=status_cb,
        )
        self._detector = detector or create_detector()
        self._sort = Sort()
        self._events = EventEngine(camera_id, camera_name)

        self.on_detections: OnDetectionsCb | None = None
        self.on_event: OnEventCb | None = None

        # 指标
        self._lock = threading.Lock()
        self._det_ids = 0
        self._last_latency_ms = 0.0
        self._last_detection_ms = 0.0
        self._last_fps = 0.0
        self._processed = 0

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # ---- 生命周期 ----

    def start(self) -> None:
        self._capture.start()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name=f"pipeline-{self.camera_id}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        self._capture.stop()
        self._detector.close()

    # ---- 内部 ----

    def _next_det_id(self) -> int:
        with self._lock:
            self._det_ids += 1
            return self._det_ids

    def _run(self) -> None:
        frame_window: list[tuple[float, float]] = []   # (处理时刻, 帧入队时刻)
        while not self._stop.is_set():
            try:
                frame = self._capture.queue.get(timeout=0.5)
            except queue.Empty:
                continue   # 队列空：循环继续

            enqueue_t = time.time()
            ts = datetime.now(timezone.utc).isoformat(timespec="milliseconds")

            try:
                self._process(frame, ts, enqueue_t, frame_window)
            except Exception:
                # 单帧处理失败不中断流水线，打印异常后继续
                import traceback

                traceback.print_exc()

    def _process(self, frame: np.ndarray, ts: str, enqueue_t: float,
                 frame_window: list[tuple[float, float]]) -> None:
        det_start = time.perf_counter()
        boxes = self._detector.detect(frame)
        det_ms = (time.perf_counter() - det_start) * 1000.0

        tracked = self._sort.update(boxes)
        new_events = self._events.update(tracked, frame.shape[:2])

        # 组装检测结果（归一化 bbox）
        h, w = frame.shape[:2]
        items: list[Detection] = []
        for t, bbox in tracked:
            nb = (bbox[0] / w, bbox[1] / h, bbox[2] / w, bbox[3] / h)
            items.append(Detection(
                id=self._next_det_id(),
                camera_id=self.camera_id,
                ts=ts,
                track_id=t.track_id,
                cls=t.box_cls,
                confidence=round(t.confidence, 3),
                bbox=(round(nb[0], 4), round(nb[1], 4), round(nb[2], 4), round(nb[3], 4)),
            ))

        # 指标快照
        latency_ms = (time.time() - enqueue_t) * 1000.0
        frame_window.append((time.time(), enqueue_t))
        frame_window[:] = [f for f in frame_window if time.time() - f[0] < 1.0]
        with self._lock:
            self._last_latency_ms = latency_ms
            self._last_detection_ms = det_ms
            self._last_fps = len(frame_window)
            self._processed += 1

        # 对外回调
        if self.on_detections and items:
            self.on_detections(self.camera_id, items)
        for ev in new_events:
            if self.on_event:
                self.on_event(ev)

    # ---- 指标查询 ----

    def metric_snapshot(self, dropped_frames: int | None = None) -> dict:
        """当前指标快照（供采样入库 / WebSocket 推送）。"""
        with self._lock:
            return {
                "ts": time.time() * 1000.0,
                "e2e_latency_ms": round(self._last_latency_ms, 1),
                "dropped_frames": dropped_frames if dropped_frames is not None else self._capture.dropped_frames,
                "queue_capacity": self._capture.queue.maxsize,
                "queue_usage": self._capture.queue_size,
                "fps": round(self._last_fps, 1),
                "detection_ms": round(self._last_detection_ms, 1),
            }

    @property
    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def in_simulated_mode(self) -> bool:
        return self._capture.in_simulated_mode
