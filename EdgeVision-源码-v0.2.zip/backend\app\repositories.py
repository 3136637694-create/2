"""仓储层：摄像头 / 告警事件 / 系统指标的参数化 SQL CRUD。

- 所有 SQL 一律使用 ? 占位符传参，防止 SQL 注入
- 返回 Pydantic 模型（snake_case DB 列 -> camelCase API 字段）
- 供第 5 步 REST 路由与实时流水线复用
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .db import Database
from .models import AlertEvent, CameraCreate, CameraInfo, CameraUpdate, EventTarget, Metric, SystemStats


def _row_to_camera(row: sqlite3.Row) -> CameraInfo:
    """DB 行 -> CameraInfo（enabled 0/1 转 bool）。"""
    d = dict(row)
    d["enabled"] = bool(d["enabled"])
    return CameraInfo.model_validate(d)


def _row_to_event(row: sqlite3.Row) -> AlertEvent:
    """DB 行 -> AlertEvent（targets JSON 字符串 -> 结构化列表）。"""
    d = dict(row)
    targets = json.loads(d.pop("targets") or "[]")
    d["targets"] = [EventTarget.model_validate(t) for t in targets]
    return AlertEvent.model_validate(d)


def _row_to_metric(row: sqlite3.Row) -> Metric:
    return Metric.model_validate(dict(row))


# ============ 摄像头 ============

class CameraRepo:
    """cameras 表 CRUD。"""

    def __init__(self, db: Database) -> None:
        self._db = db

    def list(self) -> list[CameraInfo]:
        rows = self._db.query_all("SELECT * FROM cameras ORDER BY id")
        return [_row_to_camera(r) for r in rows]

    def get(self, camera_id: int) -> CameraInfo | None:
        row = self._db.query_one("SELECT * FROM cameras WHERE id = ?", (camera_id,))
        return _row_to_camera(row) if row else None

    def create(self, data: CameraCreate) -> CameraInfo:
        """新增摄像头，初始状态 offline。"""
        row_id = self._db.execute(
            "INSERT INTO cameras (name, location, source, status, fps, resolution, enabled) "
            "VALUES (?, ?, ?, 'offline', ?, ?, 1)",
            (data.name, data.location, data.source, data.fps, data.resolution),
        )
        created = self.get(row_id)
        assert created is not None
        return created

    def update(self, camera_id: int, data: CameraUpdate) -> CameraInfo | None:
        """部分字段更新（仅更新非 None 字段），参数化动态拼接。"""
        fields: dict[str, Any] = data.model_dump(exclude_unset=True, exclude_none=True)
        if not fields:
            return self.get(camera_id)
        sets = ", ".join(f"{k} = ?" for k in fields)
        self._db.execute(
            f"UPDATE cameras SET {sets} WHERE id = ?",
            (*fields.values(), camera_id),
        )
        return self.get(camera_id)

    def delete(self, camera_id: int) -> bool:
        with self._db._lock:
            cur = self._db._conn.execute("DELETE FROM cameras WHERE id = ?", (camera_id,))
            self._db._conn.commit()
            return cur.rowcount > 0

    def set_status(self, camera_id: int, status: str, last_seen: str = "") -> None:
        """由采集/推理流水线更新运行状态与最近收帧时间。"""
        self._db.execute(
            "UPDATE cameras SET status = ?, last_seen = ? WHERE id = ?",
            (status, last_seen, camera_id),
        )


# ============ 告警事件 ============

class EventRepo:
    """events 表：历史告警分页查询 + 实时写入。"""

    def __init__(self, db: Database) -> None:
        self._db = db

    def list(
        self,
        event_type: str | None = None,
        level: str | None = None,
        camera_id: int | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> tuple[list[AlertEvent], int]:
        """按 类型/等级/摄像头 过滤 + 分页，按时间倒序。"""
        where: list[str] = []
        params: list[Any] = []
        if event_type:
            where.append("type = ?")
            params.append(event_type)
        if level:
            where.append("level = ?")
            params.append(level)
        if camera_id:
            where.append("camera_id = ?")
            params.append(camera_id)
        clause = ("WHERE " + " AND ".join(where)) if where else ""

        total = self._db.query_one(f"SELECT COUNT(*) AS c FROM events {clause}", tuple(params))["c"]
        rows = self._db.query_all(
            f"SELECT * FROM events {clause} ORDER BY ts DESC, id DESC LIMIT ? OFFSET ?",
            (*params, page_size, (page - 1) * page_size),
        )
        return [_row_to_event(r) for r in rows], int(total)

    def create(self, event: AlertEvent) -> AlertEvent:
        """写入一条告警事件（targets 序列化为 JSON 存储）。"""
        targets = json.dumps(
            [t.model_dump(by_alias=True) for t in event.targets],
            ensure_ascii=False,
        )
        row_id = self._db.execute(
            "INSERT INTO events (camera_id, camera_name, type, level, message, targets, ts) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (event.camera_id, event.camera_name, event.type, event.level, event.message, targets, event.ts),
        )
        row = self._db.query_one("SELECT * FROM events WHERE id = ?", (row_id,))
        assert row is not None
        return _row_to_event(row)


# ============ 系统指标 ============

class MetricRepo:
    """metrics 表：采样写入 + 最近 N 条查询。"""

    def __init__(self, db: Database) -> None:
        self._db = db

    def insert(self, m: Metric) -> int:
        return self._db.execute(
            "INSERT INTO metrics (ts, e2e_latency_ms, dropped_frames, queue_capacity, queue_usage, fps, detection_ms) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (m.ts, m.e2e_latency_ms, m.dropped_frames, m.queue_capacity, m.queue_usage, m.fps, m.detection_ms),
        )

    def recent(self, limit: int = 60) -> list[Metric]:
        """最近 limit 条指标（按时间升序返回，供折线图展示）。"""
        rows = self._db.query_all(
            "SELECT * FROM metrics ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        return [_row_to_metric(r) for r in reversed(rows)]

    def latest(self) -> Metric | None:
        row = self._db.query_one("SELECT * FROM metrics ORDER BY id DESC LIMIT 1")
        return _row_to_metric(row) if row else None


# ============ 系统统计 ============

class StatsRepo:
    """聚合系统概览统计（GET /api/system/stats）。"""

    def __init__(self, db: Database) -> None:
        self._db = db

    def summary(
        self,
        version: str,
        model: str,
        uptime_sec: int,
        camera_repo: CameraRepo | None = None,
        metric_repo: MetricRepo | None = None,
    ) -> SystemStats:
        cam = camera_repo or CameraRepo(self._db)
        met = metric_repo or MetricRepo(self._db)

        cameras = cam.list()
        cameras_total = len(cameras)
        cameras_online = sum(1 for c in cameras if c.status == "online")

        # 今日零点（UTC，ISO 毫秒格式，与事件 ts 同格式保证字典序可比较）
        today_start = (
            datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            .isoformat(timespec="milliseconds")
        )
        events_today = self._db.query_one(
            "SELECT COUNT(*) AS c FROM events WHERE ts >= ?", (today_start,)
        )["c"]
        critical_events = self._db.query_one(
            "SELECT COUNT(*) AS c FROM events WHERE ts >= ? AND level = 'critical'", (today_start,)
        )["c"]

        avg_latency = self._db.query_one(
            "SELECT AVG(e2e_latency_ms) AS a FROM (SELECT e2e_latency_ms FROM metrics ORDER BY id DESC LIMIT 20)"
        )["a"] or 0.0

        latest = met.latest()
        dropped_frames = latest.dropped_frames if latest else 0
        queue_usage = latest.queue_usage if latest else 0.0

        return SystemStats(
            cameras_total=cameras_total,
            cameras_online=cameras_online,
            events_today=int(events_today),
            critical_events=int(critical_events),
            avg_latency_ms=round(float(avg_latency), 1),
            dropped_frames=dropped_frames,
            queue_usage=round(queue_usage, 1),
            uptime_sec=uptime_sec,
            version=version,
            model=model,
        )


# 进程级仓储单例（复用 db 单例）
from .db import db as _db  # noqa: E402

cameras: CameraRepo = CameraRepo(_db)
events: EventRepo = EventRepo(_db)
metrics: MetricRepo = MetricRepo(_db)
stats: StatsRepo = StatsRepo(_db)
