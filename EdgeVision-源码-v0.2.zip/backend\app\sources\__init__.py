"""视频采集模块：帧源抽象 + RTSP 采集 + 模拟源 + 生产者队列。"""

from .capture import CaptureWorker
from .frame_source import FrameSource
from .rtsp_capture import RTSPCapture
from .simulated import SimulatedSource

__all__ = ["CaptureWorker", "FrameSource", "RTSPCapture", "SimulatedSource"]
