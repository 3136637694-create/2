"""采集生产者：每路摄像头一个采集线程 + 有界队列。

- 生产者-消费者解耦：线程循环读帧 -> 有界 queue.Queue
- 队列满时丢帧保护（put_nowait 失败即丢弃），防止内存持续上涨
- RTSP 断线：指数退避重连（rtsp_retry_base * 2^n，上限 rtsp_retry_max）
- 打开失败时自动回退 SimulatedSource，保证演示环境可用
"""

from __future__ import annotations

import queue
import sys
import threading
import time

import numpy as np

from ..config import settings
from .frame_source import FrameSource
from .rtsp_capture import RTSPCapture
from .simulated import SimulatedSource

# 回调：摄像头运行状态变更（online / offline / reconnecting）
StatusCb = callable  # type: ignore


class CaptureWorker:
    """单路摄像头采集任务。start() 后独立线程持续生产帧到队列。"""

    def __init__(
        self,
        camera_id: int,
        source: str,
        target_fps: int = 15,
        queue_capacity: int = 100,
        fallback_simulated: bool = True,
        status_cb: StatusCb | None = None,
    ) -> None:
        self.camera_id = camera_id
        self.source = source
        self.target_fps = target_fps
        self.queue: queue.Queue[np.ndarray] = queue.Queue(maxsize=queue_capacity)
        self.fallback_simulated = fallback_simulated
        self._status_cb = status_cb

        self.dropped_frames = 0           # 丢帧计数（可观测性指标）
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._latest_frame: np.ndarray | None = None   # 最新帧（供 MJPEG 流 / 快照读取）

        self._src: FrameSource | None = None
        self._simulated_mode = False      # 是否已回退到模拟源

    # ---- 生命周期 ----

    def start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name=f"capture-{self.camera_id}", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        if self._src is not None:
            self._src.close()

    # ---- 内部 ----

    def _init_com_on_thread(self) -> None:
        """Windows 采集子线程初始化 COM。

        - DirectShow（本地摄像头默认后端）要求 STA 公寓
        - 未初始化 COM 时 VideoCapture 在本线程会 open/read 失败或阻塞
        仅在 Windows 生效，其他平台无副作用。
        """
        if sys.platform != "win32":
            return
        try:
            import ctypes

            ctypes.windll.ole32.CoInitialize(None)  # STA（DirectShow 要求）
        except Exception:
            pass

    def _uninit_com_on_thread(self) -> None:
        """Windows 释放本线程 COM 公寓。

        摄像头关闭/重开一轮后，DirectShow 设备句柄可能未完全释放，
        重开前须先 CoUninitialize 再 CoInitialize，否则 reopen 会卡住。
        """
        if sys.platform != "win32":
            return
        try:
            import ctypes

            ctypes.windll.ole32.CoUninitialize()
        except Exception:
            pass

    def _set_status(self, status: str) -> None:
        if self._status_cb:
            try:
                self._status_cb(self.camera_id, status)
            except Exception:
                pass

    def _emit(self, frame: np.ndarray) -> None:
        """入队；满则丢弃并计数（丢帧保护）。同时缓存最新帧供 MJPEG 流。"""
        self._latest_frame = frame
        try:
            self.queue.put_nowait(frame)
        except queue.Full:
            with self._lock:
                self.dropped_frames += 1

    def latest_frame(self) -> np.ndarray | None:
        """读取最新一帧（MJPEG 流 / 画面预览用）。"""
        return self._latest_frame

    def _open_source(self) -> FrameSource:
        """优先 RTSP/本地摄像头，失败且允许时回退模拟源。"""
        src: FrameSource = RTSPCapture(self.source)
        if src.open():
            self._simulated_mode = False
            return src
        print(f"[capture-{self.camera_id}] open FAILED source={self.source!r} fallback={self.fallback_simulated}", flush=True)
        src.close()
        if self.fallback_simulated:
            self._simulated_mode = True
            sim = SimulatedSource(self.source)
            sim.open()
            return sim
        return src

    def _run(self) -> None:
        self._init_com_on_thread()
        retry = 0
        interval = 1.0 / max(1, self.target_fps)
        last_real_attempt = 0.0   # 模拟模式下最近一次尝试重开真实源的时间戳

        while not self._stop.is_set():
            # 已回退模拟源时，周期性尝试恢复真实摄像头（用户重启摄像头后自动切回）
            if self._simulated_mode and (time.time() - last_real_attempt) >= 5.0:
                last_real_attempt = time.time()
                self._uninit_com_on_thread()
                self._init_com_on_thread()
                real = RTSPCapture(self.source)
                if real.open():
                    old = self._src
                    self._src = real
                    self._simulated_mode = False
                    if old is not None:
                        old.close()
                    self._set_status("online")
                    retry = 0
                    print(f"[capture-{self.camera_id}] camera back, switched to real source", flush=True)

            # 确保帧源已打开
            if self._src is None:
                self._src = self._open_source()
                if not (self._src is not None and self._simulated_mode):
                    # 打开失败且未回退模拟源：指数退避后重试
                    self._set_status("reconnecting")
                    retry += 1
                    delay = min(settings.rtsp_retry_base * (2 ** (retry - 1)), settings.rtsp_retry_max)
                    time.sleep(delay)
                    continue
                self._set_status("online")
                retry = 0

            start = time.perf_counter()
            ok, frame = self._src.read()
            if ok and frame is not None:
                # 一旦持续读到帧即回写 online（消除打开成功瞬间曾置 reconnecting 的竞态）
                self._set_status("online")
                self._emit(frame)
            else:
                # 读帧失败：关闭源，进入退避重连
                self._src.close()
                self._src = None
                self._set_status("reconnecting")
                retry += 1
                delay = min(settings.rtsp_retry_base * (2 ** (retry - 1)), settings.rtsp_retry_max)
                if self._simulated_mode:
                    # 模拟源不应失败，异常时短暂休眠防止空转
                    time.sleep(0.2)
                else:
                    time.sleep(delay)
                continue

            # 帧率节流
            elapsed = time.perf_counter() - start
            if elapsed < interval:
                time.sleep(interval - elapsed)

    @property
    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def queue_size(self) -> int:
        return self.queue.qsize()

    @property
    def in_simulated_mode(self) -> bool:
        return self._simulated_mode
