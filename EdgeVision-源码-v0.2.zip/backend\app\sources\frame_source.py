"""帧源抽象基类：采集模块可替换实现（RTSP / 模拟源 / 本地摄像头）。"""

from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


class FrameSource(ABC):
    """统一帧源接口。业务代码只依赖本抽象，不绑定具体采集方式。"""

    source: str

    @abstractmethod
    def open(self) -> bool:
        """打开帧源。返回是否成功。"""

    @abstractmethod
    def read(self) -> tuple[bool, np.ndarray | None]:
        """读取一帧 BGR 图像。返回 (成功, 帧)；失败时帧为 None。"""

    @abstractmethod
    def close(self) -> None:
        """关闭帧源，释放资源。"""
