"""RTSP / 本地摄像头采集：基于 OpenCV VideoCapture 的 FrameSource 实现。"""

from __future__ import annotations

import sys

import cv2
import numpy as np

from .frame_source import FrameSource


class RTSPCapture(FrameSource):
    """OpenCV 视频捕获。

    - 支持 RTSP 网络流（rtsp://...）与本地摄像头（如 0）
    - Windows 本地摄像头用 DirectShow 后端（MSMF 在多线程打开时会阻塞，已知坑）
    - 打开失败 / 读取失败由上层 CaptureWorker 负责退避重连，本类不做重试逻辑
    """

    def __init__(self, source: str) -> None:
        self.source = source
        self._cap: cv2.VideoCapture | None = None

    def open(self) -> bool:
        # 纯数字字符串视为本机摄像头索引（如 "0"），OpenCV 对字符串 "0" 会当文件名解析
        if self.source.isdigit():
            cap = self._open_local(int(self.source))
        else:
            cap = cv2.VideoCapture(self.source)
        # 减少缓冲，降低端到端延迟
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not cap.isOpened():
            cap.release()
            self._cap = None
            return False
        self._cap = cap
        return True

    def _open_local(self, index: int) -> cv2.VideoCapture:
        """打开本机摄像头：Windows 用 DirectShow + MJPG 编码（30fps 稳定）。"""
        if sys.platform == "win32":
            cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            cap.set(cv2.CAP_PROP_FPS, 15)
            return cap
        return cv2.VideoCapture(index)

    def read(self) -> tuple[bool, np.ndarray | None]:
        if self._cap is None:
            return False, None
        ok, frame = self._cap.read()
        if not ok:
            return False, None
        return True, frame

    def close(self) -> None:
        if self._cap is not None:
            self._cap.release()
            self._cap = None
