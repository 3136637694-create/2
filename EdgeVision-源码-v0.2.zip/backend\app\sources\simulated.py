"""模拟帧源：无摄像头 / RTSP 不可达时合成动态画面。

- 暗色底 + 移动目标（圆形）+ 随机噪声，模拟真实监控画面
- 移动目标坐标随时间演进，后续可直接叠加检测框/轨迹验证流水线
"""

from __future__ import annotations

import time

import cv2
import numpy as np

from .frame_source import FrameSource

_W = 640
_H = 480


class SimulatedSource(FrameSource):
    """合成视频源，source 任意占位字符串。"""

    def __init__(self, source: str = "simulated") -> None:
        self.source = source
        self._open = False

    def open(self) -> bool:
        self._open = True
        return True

    def read(self) -> tuple[bool, np.ndarray | None]:
        if not self._open:
            return False, None
        t = time.time()
        frame = np.full((_H, _W, 3), 18, dtype=np.uint8)   # 深色底
        # 网格与噪点增强真实感
        cv2.line(frame, (_W // 2, 0), (_W // 2, _H), (36, 36, 40), 1)
        cv2.line(frame, (0, _H // 2), (_W, _H // 2), (36, 36, 40), 1)
        rng = np.random.default_rng(int(t * 1000) % 2**32)
        frame += rng.integers(0, 6, (_H, _W, 1), dtype=np.uint8)

        # 若干移动目标：绿色圆形（模拟行人），轨迹随时间漂移
        for i in range(3):
            cx = int((_W * (0.2 + 0.6 * ((t / 3 + i * 0.33) % 1.0))))
            cy = int((_H * (0.3 + 0.3 * ((t / 5 + i * 0.47) % 1.0))))
            cv2.circle(frame, (cx, cy), 14, (60, 170, 90), -1)
            cv2.circle(frame, (cx, cy), 14, (120, 200, 140), 2)
        # 顶部标题条
        cv2.rectangle(frame, (0, 0), (_W, 26), (30, 30, 34), -1)
        cv2.putText(frame, f"SIMULATED  {self.source}", (8, 18),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (140, 220, 190), 1, cv2.LINE_AA)
        return True, frame

    def close(self) -> None:
        self._open = False
