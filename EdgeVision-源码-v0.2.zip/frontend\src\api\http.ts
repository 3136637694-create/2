import axios from 'axios'

// 统一 axios 实例；后端就绪后经 vite proxy 转发到 FastAPI(8000)
const http = axios.create({
  baseURL: '/api',
  timeout: 8000,
})

http.interceptors.response.use(
  (res) => res,
  (err) => {
    // 统一错误处理：静默失败，由调用方决定提示文案
    return Promise.reject(err)
  },
)

export default http
