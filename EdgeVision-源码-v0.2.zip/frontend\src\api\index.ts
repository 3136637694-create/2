// ============ API 桩层 ============
// TODO(后端就绪): 将各函数的 mock 分支替换为真实请求——函数签名与下方注释中的 METHOD + PATH
// 一一对应（GET/POST /api/cameras、PUT/DELETE /api/cameras/{id}、GET /api/events、
// GET /api/metrics、GET /api/system/stats），响应结构保持不变即可无缝切换。

import type { AlertEvent, CameraInfo, Metric, SystemStats } from '@/types'
import http from './http'
import { dataMode } from '@/config'
import { mockCameras, mockEvents } from '@/mock/data'

function delay(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms))
}

function clamp<T>(arr: T[], page: number, size: number): T[] {
  const start = (page - 1) * size
  return arr.slice(start, start + size)
}

function mockNextId(items: { id: number }[]): number {
  return items.length ? Math.max(...items.map((i) => i.id)) + 1 : 1
}

// ============ 摄像头 ============

/** GET /cameras 获取全部摄像头配置 */
export async function getCameras(): Promise<CameraInfo[]> {
  if (dataMode.value === 'api') {
    const { data } = await http.get('/cameras')
    return data
  }
  await delay(350)
  return structuredClone(mockCameras)
}

/** POST /cameras 新增摄像头 */
export async function addCamera(payload: Omit<CameraInfo, 'id' | 'status' | 'lastSeen'>): Promise<CameraInfo> {
  if (dataMode.value === 'api') {
    const { data } = await http.post('/cameras', payload)
    return data
  }
  await delay(400)
  const cam: CameraInfo = {
    ...payload,
    id: mockNextId(mockCameras),
    status: 'online',
    lastSeen: '实时',
  }
  mockCameras.push(cam)
  return cam
}

/** PUT /cameras/{id} 更新摄像头配置 */
export async function updateCamera(id: number, payload: Partial<CameraInfo>): Promise<CameraInfo> {
  if (dataMode.value === 'api') {
    const { data } = await http.put(`/cameras/${id}`, payload)
    return data
  }
  await delay(400)
  const idx = mockCameras.findIndex((c) => c.id === id)
  mockCameras[idx] = { ...mockCameras[idx], ...payload }
  return mockCameras[idx]
}

/** DELETE /cameras/{id} 删除摄像头 */
export async function deleteCamera(id: number): Promise<void> {
  if (dataMode.value === 'api') {
    await http.delete(`/cameras/${id}`)
    return
  }
  await delay(350)
  const idx = mockCameras.findIndex((c) => c.id === id)
  if (idx >= 0) mockCameras.splice(idx, 1)
}

// ============ 告警事件 ============

export interface AlertQuery {
  type?: string
  level?: string
  cameraId?: number
  page: number
  pageSize: number
}

export interface AlertPage {
  items: AlertEvent[]
  total: number
}

/** GET /events?type=&level=&camera_id=&page=&page_size= 历史告警分页查询 */
export async function getAlerts(q: AlertQuery): Promise<AlertPage> {
  if (dataMode.value === 'api') {
    const { data } = await http.get('/events', { params: q })
    return data
  }
  await delay(450)
  let list = mockEvents
  if (q.type && q.type !== 'all') list = list.filter((e) => e.type === q.type)
  if (q.level && q.level !== 'all') list = list.filter((e) => e.level === q.level)
  if (q.cameraId) list = list.filter((e) => e.cameraId === q.cameraId)
  list = [...list].sort((a, b) => (a.ts < b.ts ? 1 : -1))
  return { items: clamp(list, q.page, q.pageSize), total: list.length }
}

// ============ 系统指标 ============

/** GET /metrics?window= 历史指标序列 */
export async function getMetrics(): Promise<Metric[]> {
  if (dataMode.value === 'api') {
    const { data } = await http.get('/metrics')
    return data
  }
  await delay(400)
  const now = Date.now()
  const base = 40
  return Array.from({ length: 60 }, (_, i) => ({
    ts: now - (59 - i) * 5000,
    e2eLatencyMs: +(base + Math.sin(i / 4) * 8 + (i % 17 === 0 ? 60 : 0) + Math.random() * 6).toFixed(1),
    droppedFrames: Math.floor((i + 1) * 1.7 + (i % 13 === 0 ? 6 : 0)),
    queueCapacity: 100,
    queueUsage: +(38 + Math.sin(i / 5) * 10 + (i % 19 === 0 ? 22 : 0)).toFixed(1),
    fps: +(22 + Math.sin(i / 6) * 3).toFixed(1),
    detectionMs: +(12 + Math.cos(i / 7) * 4 + Math.random() * 3).toFixed(1),
  }))
}

/** GET /system/stats 系统概览统计 */
export async function getSystemStats(): Promise<SystemStats> {
  if (dataMode.value === 'api') {
    const { data } = await http.get('/system/stats')
    return data
  }
  await delay(300)
  const online = mockCameras.filter((c) => c.status === 'online').length
  return {
    camerasTotal: mockCameras.length,
    camerasOnline: online,
    eventsToday: 32,
    criticalEvents: 5,
    avgLatencyMs: 46.2,
    droppedFrames: 284,
    queueUsage: 41.5,
    uptimeSec: 3 * 3600 + 47 * 60 + 12,
    version: '0.1.0',
    model: 'YOLOv8n · ONNX Runtime',
  }
}
