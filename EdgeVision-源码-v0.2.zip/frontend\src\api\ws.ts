import type { WsFrame } from '@/types'
import { dataMode } from '@/config'
import { simulator } from '@/mock/simulator'

// ============ WebSocket 实时通道（多订阅者共享） ============
// mock 模式：本地 Simulator 定时推送；api 模式：连接后端 /ws/monitor。
// 对外统一 subscribe(callback) → unsubscribe()。

const subs = new Set<(f: WsFrame) => void>()
let started = false
let realWs: WebSocket | null = null

function start(): void {
  if (dataMode.value === 'api') {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws'
    realWs = new WebSocket(`${proto}://${location.host}/ws/monitor`)
    realWs.onmessage = (e) => {
      try {
        const f = JSON.parse(e.data) as WsFrame
        for (const cb of subs) cb(f)
      } catch {
        /* 忽略解析失败帧 */
      }
    }
    realWs.onerror = () => realWs?.close()
    return
  }
  simulator.onDetections = (cameraId, items) =>
    broadcast({ kind: 'detections', cameraId, ts: new Date().toISOString(), items })
  simulator.onEvent = (event) => broadcast({ kind: 'event', event })
  simulator.onMetric = (metric) => broadcast({ kind: 'metric', metric })
  simulator.start()
}

function broadcast(f: WsFrame): void {
  for (const cb of subs) cb(f)
}

function stop(): void {
  if (dataMode.value === 'api') {
    realWs?.close()
    realWs = null
  } else {
    simulator.stop()
  }
}

export function subscribeMonitor(cb: (f: WsFrame) => void): () => void {
  subs.add(cb)
  if (!started) {
    started = true
    start()
  }
  return () => {
    subs.delete(cb)
    if (subs.size === 0 && started) {
      started = false
      stop()
    }
  }
}
