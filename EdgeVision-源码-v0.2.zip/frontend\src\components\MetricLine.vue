<template>
  <div class="metric-chart">
    <div ref="chartRef" class="chart-box" />
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'
import * as echarts from 'echarts'
import type { Metric } from '@/types'
import { fmtClock } from '@/utils/format'

// ============ 通用指标折线图（echarts，暗色适配） ============

const props = defineProps<{
  title: string
  unit: string
  color: string
  data: Metric[]
  field: 'e2eLatencyMs' | 'queueUsage' | 'droppedFrames'
}>()

const chartRef = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null

function buildOption(): echarts.EChartsOption {
  return {
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#1a2231',
      borderColor: '#2a3852',
      textStyle: { color: '#e6edf3', fontSize: 12 },
      formatter: (params: unknown) => {
        const p = (params as { axisValue?: string | number; value?: number }[])[0]
        return `${props.title}<br/>${p.axisValue ?? ''}：<b>${p.value ?? 0} ${props.unit}</b>`
      },
    },
    grid: { left: 12, right: 14, top: 34, bottom: 8, containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: props.data.map((m) => fmtClock(new Date(m.ts).toISOString())),
      axisLine: { lineStyle: { color: '#1e2838' } },
      axisLabel: { color: '#8b9ab0', fontSize: 11 },
      splitLine: { show: false },
    },
    yAxis: {
      type: 'value',
      name: props.unit,
      nameTextStyle: { color: '#8b9ab0', fontSize: 11 },
      axisLabel: { color: '#8b9ab0', fontSize: 11 },
      splitLine: { lineStyle: { color: 'rgba(30,40,56,0.6)', type: 'dashed' } },
    },
    series: [
      {
        name: props.title,
        type: 'line',
        smooth: true,
        symbol: 'none',
        data: props.data.map((m) => m[props.field]),
        lineStyle: { width: 2, color: props.color },
        itemStyle: { color: props.color },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: props.color + '33' },
              { offset: 1, color: props.color + '00' },
            ],
          },
        },
      },
    ],
  }
}

onMounted(() => {
  if (!chartRef.value) return
  chart = echarts.init(chartRef.value)
  chart.setOption(buildOption())
  window.addEventListener('resize', onResize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  chart?.dispose()
  chart = null
})

function onResize(): void {
  chart?.resize()
}

watch(
  () => props.data,
  () => chart?.setOption(buildOption()),
  { deep: true },
)
</script>

<style scoped>
.metric-chart {
  width: 100%;
}
.chart-box {
  width: 100%;
  height: 260px;
}
</style>
