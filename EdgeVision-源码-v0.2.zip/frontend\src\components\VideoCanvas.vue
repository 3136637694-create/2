<template>
  <div class="video-canvas-wrap">
    <img
      v-if="videoSrc"
      :key="videoKey"
      :src="videoSrc"
      class="video-frame"
      alt="实时监控画面"
      @error="onVideoError"
    />
    <canvas ref="cvRef" :width="W" :height="H" class="video-canvas" />
    <div v-if="!connected" class="overlay-msg">
      <span class="dot warn" />视频流断开 · 自动重连中…
    </div>
    <div v-else-if="noFrame" class="overlay-msg">等待首帧…</div>
    <div v-if="connected && !noFrame" class="corner-time mono">{{ cornerTime }} · {{ cameraName }}</div>
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import type { Detection } from '@/types'
import type { HistoryPoint } from '@/stores/monitor'
import { fmtClock } from '@/utils/format'

// ============ Mock 视频画面 + 检测叠加 Canvas ============
// 真实模式：由后端 MJPEG 流 <img> 取代此画布，叠加层绘制逻辑可复用。

const props = defineProps<{
  detections: Detection[]
  trackHistory: Map<number, HistoryPoint[]>
  showBoxes: boolean
  showIds: boolean
  showTrails: boolean
  connected: boolean
  noFrame: boolean
  cameraName: string
  /** 真实模式 MJPEG 流地址（如 /stream/6），非空时由后端视频画面替代 Canvas 模拟场景 */
  videoSrc?: string
}>()

const W = 960
const H = 540
const cvRef = ref<HTMLCanvasElement | null>(null)

// ---- MJPEG 流自动重连：流断开（error）后延时重建 <img> 触发浏览器重试 ----
const videoKey = ref(0)
let retryTimer: number | null = null
function onVideoError(): void {
  if (retryTimer !== null) return
  retryTimer = window.setTimeout(() => {
    retryTimer = null
    videoKey.value += 1
  }, 2000)
}
onBeforeUnmount(() => {
  if (retryTimer !== null) window.clearTimeout(retryTimer)
})

const cornerTime = ref(fmtClock(new Date().toISOString()))
setInterval(() => {
  cornerTime.value = fmtClock(new Date().toISOString())
}, 1000)

const CLS_COLOR: Record<string, string> = {
  person: '#22D3EE',
  vehicle: '#FBBF24',
  object: '#34D399',
}
const CLS_TEXT: Record<string, string> = { person: '人', vehicle: '车', object: '物' }

function rand(min: number, max: number): number {
  return min + Math.random() * (max - min)
}

// ---- 场景：监控走廊/路口，带透视地面、窗户、走动光斑 ----
function drawScene(ctx: CanvasRenderingContext2D, t: number): void {
  ctx.clearRect(0, 0, W, H)

  // 墙壁
  const wall = ctx.createLinearGradient(0, 0, 0, H * 0.52)
  wall.addColorStop(0, '#10161f')
  wall.addColorStop(1, '#1b2330')
  ctx.fillStyle = wall
  ctx.fillRect(0, 0, W, H * 0.52)

  // 地面（透视网格）
  const floorGrad = ctx.createLinearGradient(0, H * 0.5, 0, H)
  floorGrad.addColorStop(0, '#232b38')
  floorGrad.addColorStop(1, '#141a24')
  ctx.fillStyle = floorGrad
  ctx.fillRect(0, H * 0.5, W, H * 0.5)

  const vy = H * 0.46 // 灭点
  ctx.strokeStyle = 'rgba(34,211,238,0.10)'
  ctx.lineWidth = 1
  for (let i = -8; i <= 8; i++) {
    ctx.beginPath()
    ctx.moveTo(W / 2 + i * W * 0.14, vy)
    ctx.lineTo(W / 2 + i * W * 0.55, H)
    ctx.stroke()
  }
  for (let i = 0; i <= 10; i++) {
    const f = i / 10
    const yy = vy + (H - vy) * f * f
    ctx.beginPath()
    ctx.moveTo(0, yy)
    ctx.lineTo(W, yy)
    ctx.stroke()
  }

  // 走廊两侧窗户
  ctx.fillStyle = 'rgba(96,165,250,0.10)'
  for (const wx of [60, W - 150]) {
    ctx.fillRect(wx, 40, 90, H * 0.32)
    ctx.strokeStyle = 'rgba(96,165,250,0.18)'
    ctx.strokeRect(wx, 40, 90, H * 0.32)
  }

  // 缓慢移动的光斑（模拟灯光/反光）
  const sweepX = ((t * 40) % (W + 300)) - 150
  const glow = ctx.createRadialGradient(sweepX, H * 0.3, 0, sweepX, H * 0.3, 260)
  glow.addColorStop(0, 'rgba(34,211,238,0.05)')
  glow.addColorStop(1, 'rgba(34,211,238,0)')
  ctx.fillStyle = glow
  ctx.fillRect(0, 0, W, H)

  // 随机噪声（模拟视频压缩噪点）
  for (let i = 0; i < 26; i++) {
    ctx.fillStyle = `rgba(255,255,255,${rand(0.008, 0.035)})`
    ctx.fillRect(rand(0, W), rand(0, H), 2, 2)
  }

  // 轻微扫描线
  ctx.fillStyle = `rgba(0,0,0,${rand(0.02, 0.05)})`
  ctx.fillRect(0, (t * 30) % H, W, 2)
}

function drawTrails(ctx: CanvasRenderingContext2D, t: number): void {
  for (const [id, pts] of props.trackHistory) {
    if (pts.length < 2) continue
    const clsColor = CLS_COLOR[props.detections.find((d) => d.trackId === id)?.cls ?? 'person']
    ctx.lineWidth = 1.6
    for (let i = 1; i < pts.length; i++) {
      const alpha = (i / pts.length) * 0.55
      ctx.strokeStyle = clsColor + hexAlpha(alpha)
      ctx.beginPath()
      ctx.moveTo(pts[i - 1].x * W, pts[i - 1].y * H)
      ctx.lineTo(pts[i].x * W, pts[i].y * H)
      ctx.stroke()
    }
    void t
  }
}

function hexAlpha(a: number): string {
  const v = Math.round(a * 255).toString(16).padStart(2, '0')
  return v
}

function drawDetections(ctx: CanvasRenderingContext2D): void {
  for (const d of props.detections) {
    const [x1, y1, x2, y2] = d.bbox
    const px = x1 * W
    const py = y1 * H
    const pw = (x2 - x1) * W
    const ph = (y2 - y1) * H
    const color = CLS_COLOR[d.cls] ?? '#22D3EE'

    if (props.showBoxes) {
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      ctx.strokeRect(px, py, pw, ph)
      // 角标点缀
      ctx.fillStyle = color + '40'
      ctx.fillRect(px, py, 6, 2)
      ctx.fillRect(px, py, 2, 6)
    }

    if (props.showIds) {
      const label = `${CLS_TEXT[d.cls] ?? d.cls} ${d.confidence.toFixed(2)}`
      const full = `ID ${String(d.trackId).padStart(4, '0')} · ${label}`
      ctx.font = '12px JetBrains Mono, monospace'
      const tw = ctx.measureText(full).width + 10
      ctx.fillStyle = 'rgba(10,14,22,0.82)'
      ctx.fillRect(px, py - 20, tw, 18)
      ctx.strokeStyle = color
      ctx.lineWidth = 1
      ctx.strokeRect(px, py - 20, tw, 18)
      ctx.fillStyle = color
      ctx.textBaseline = 'middle'
      ctx.fillText(full, px + 5, py - 11)
    }
  }
}

let raf = 0
function loop(): void {
  raf = requestAnimationFrame(loop)
  const cv = cvRef.value
  if (!cv) return
  const ctx = cv.getContext('2d')
  if (!ctx) return
  const t = performance.now() / 1000
  // 先清空画布，避免残留模拟场景遮挡下方 MJPEG 流
  ctx.clearRect(0, 0, W, H)
  // 真实模式：底层由 <img> 播放 MJPEG 流，画布只绘制叠加层
  if (!props.videoSrc) drawScene(ctx, t)
  if (props.connected && !props.noFrame) {
    if (props.showTrails) drawTrails(ctx, t)
    drawDetections(ctx)
  }
}

onMounted(() => {
  loop()
})
onBeforeUnmount(() => {
  cancelAnimationFrame(raf)
})
</script>

<style scoped>
.video-canvas-wrap {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  overflow: hidden;
  border-radius: var(--ev-radius-md);
  background: #0a0e16;
}

.video-canvas {
  position: relative;
  display: block;
  width: 100%;
  height: 100%;
}

/* 真实模式：后端 MJPEG 流作为底层画面，画布叠加层覆盖其上 */
.video-frame {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  background: #0a0e16;
}

.overlay-msg {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  background: rgba(8, 11, 18, 0.72);
  color: var(--ev-text-sub);
  font-size: var(--ev-fs-14);
  backdrop-filter: blur(2px);
}

.overlay-msg .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ev-warning);
  animation: blink 1.2s ease-in-out infinite;
}
@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}

.corner-time {
  position: absolute;
  right: 10px;
  bottom: 8px;
  font-size: 12px;
  color: rgba(230, 237, 243, 0.75);
  background: rgba(10, 14, 22, 0.55);
  padding: 2px 8px;
  border-radius: 4px;
  letter-spacing: 0.5px;
}
</style>
