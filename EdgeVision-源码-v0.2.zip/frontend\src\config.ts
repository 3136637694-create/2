import { ref } from 'vue'

// ============ 数据模式：mock | api（一键切换，localStorage 持久化） ============
export type DataMode = 'mock' | 'api'

const saved = (localStorage.getItem('ev_mode') as DataMode) || 'mock'
export const dataMode = ref<DataMode>(saved)

export function setDataMode(mode: DataMode): void {
  dataMode.value = mode
  localStorage.setItem('ev_mode', mode)
}
