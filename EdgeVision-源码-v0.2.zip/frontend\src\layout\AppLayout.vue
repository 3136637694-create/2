<template>
  <div class="app-shell">
    <div class="ev-grid-bg" aria-hidden="true" />

    <!-- ======== 侧边栏（唯一导航，所有页面共用） ======== -->
    <aside class="sidebar">
      <div class="brand">
        <svg class="brand-logo" viewBox="0 0 32 32" aria-hidden="true">
          <rect x="1" y="1" width="30" height="30" rx="6" fill="none" stroke="#22D3EE" stroke-opacity=".5" />
          <path d="M10 12h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2z" fill="none" stroke="#22D3EE" stroke-width="1.8" />
          <circle cx="16" cy="18" r="3.2" fill="none" stroke="#22D3EE" stroke-width="1.5" />
          <path d="M10 12l2-3h4l2 3" fill="none" stroke="#22D3EE" stroke-width="1.8" stroke-linejoin="round" />
          <circle cx="23" cy="9" r="2" fill="#FBBF24" />
        </svg>
        <div class="brand-text">
          <b>EdgeVision</b>
          <span>边缘端实时视觉分析</span>
        </div>
      </div>

      <el-menu :default-active="activeMenu" router class="ev-menu">
        <el-menu-item v-for="item in navItems" :key="item.path" :index="item.path">
          <el-icon><component :is="item.icon" /></el-icon>
          <span>{{ item.label }}</span>
        </el-menu-item>
      </el-menu>

      <div class="sidebar-foot">
        <span class="mono">v{{ app.stats?.version ?? '0.1.0' }}</span>
        <span class="mono">{{ app.stats?.model ?? 'YOLOv8n · ONNX' }}</span>
      </div>
    </aside>

    <!-- ======== 主区域 ======== -->
    <div class="main-area">
      <header class="topbar">
        <div class="tb-left">
          <span class="page-title">{{ route.meta.title }}</span>
        </div>
        <div class="tb-right">
          <span class="sys-status">
            <span class="dot" :class="{ offline: !monitor.connected && !isOnMonitor }" />
            <span>系统运行中</span>
          </span>

          <div class="mode-switch" title="Mock：本地模拟数据；API：对接后端 FastAPI 接口">
            <span class="mode-label">数据模式</span>
            <el-switch
              :model-value="isApi"
              :active-value="true"
              :inactive-value="false"
              active-text="API"
              inactive-text="Mock"
              @update:model-value="onModeChange"
            />
          </div>

          <el-badge :value="alerts.liveUnread" :hidden="alerts.liveUnread === 0" class="alert-badge">
            <el-button circle :icon="Bell" size="small" @click="goAlerts" />
          </el-badge>

          <span class="clock mono">{{ timeStr }}</span>
        </div>
      </header>

      <main class="content">
        <router-view v-slot="{ Component }">
          <transition name="fade-slide" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Bell, Camera, DataAnalysis, VideoCamera } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useAppStore } from '@/stores/app'
import { useCamerasStore } from '@/stores/cameras'
import { useAlertsStore } from '@/stores/alerts'
import { useMonitorStore } from '@/stores/monitor'

const route = useRoute()
const router = useRouter()
const app = useAppStore()
const cameras = useCamerasStore()
const alerts = useAlertsStore()
const monitor = useMonitorStore()

const navItems = [
  { label: '实时监控', path: '/monitor', icon: VideoCamera },
  { label: '摄像头管理', path: '/cameras', icon: Camera },
  { label: '告警事件', path: '/alerts', icon: Bell },
  { label: '系统指标', path: '/metrics', icon: DataAnalysis },
]

const activeMenu = computed(() => route.path)
const isApi = computed(() => app.mode === 'api')
const isOnMonitor = computed(() => route.path === '/monitor')
const timeStr = computed(() =>
  app.now.toTimeString().slice(0, 8),
)

function onModeChange(val: string | number | boolean): void {
  app.switchMode(val ? 'api' : 'mock')
  ElMessage({
    message: val ? '已切换为 API 模式（对接后端接口）' : '已切换为 Mock 模式（本地模拟数据）',
    type: val ? 'info' : 'success',
  })
  // 重新拉取静态数据；实时通道在重新进入页面时按新模式建立
  cameras.load()
  app.loadStats()
}

function goAlerts(): void {
  alerts.clearUnread()
  router.push('/alerts')
}

onMounted(() => {
  app.loadStats()
  cameras.load()
})
</script>

<style scoped>
.app-shell {
  position: relative;
  min-height: 100vh;
}

/* ===== 侧边栏 ===== */
.sidebar {
  position: fixed;
  inset: 0 auto 0 0;
  width: var(--ev-sidebar-w);
  z-index: 10;
  display: flex;
  flex-direction: column;
  background: linear-gradient(180deg, #101624 0%, #0c111d 100%);
  border-right: 1px solid var(--ev-border);
}

.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 18px 16px 16px;
  border-bottom: 1px solid var(--ev-border);
}

.brand-logo {
  width: 34px;
  height: 34px;
  flex: none;
}

.brand-text {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
}
.brand-text b {
  font-size: var(--ev-fs-16);
  letter-spacing: 0.5px;
  color: var(--ev-text);
}
.brand-text span {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
  margin-top: 2px;
}

.ev-menu {
  flex: 1;
  border-right: none;
  background: transparent;
  padding: 12px 10px;
}

/* Element Plus 菜单暗色化 */
.ev-menu :deep(.el-menu-item) {
  height: 44px;
  margin-bottom: 4px;
  border-radius: var(--ev-radius-md);
  color: var(--ev-text-sub);
  font-size: var(--ev-fs-14);
}
.ev-menu :deep(.el-menu-item .el-icon) {
  font-size: 18px;
}
.ev-menu :deep(.el-menu-item:hover) {
  background: rgba(34, 211, 238, 0.08);
  color: var(--ev-text);
}
.ev-menu :deep(.el-menu-item.is-active) {
  background: var(--ev-primary-dim);
  color: var(--ev-primary);
  box-shadow: inset 0 0 0 1px rgba(34, 211, 238, 0.35);
}

.sidebar-foot {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 14px 16px;
  border-top: 1px solid var(--ev-border);
  color: var(--ev-text-sub);
  font-size: var(--ev-fs-12);
}

/* ===== 主区域 ===== */
.main-area {
  margin-left: var(--ev-sidebar-w);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.topbar {
  position: sticky;
  top: 0;
  z-index: 9;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 60px;
  padding: 0 24px;
  background: rgba(11, 15, 25, 0.82);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid var(--ev-border);
}

.tb-left {
  display: flex;
  align-items: center;
  gap: 12px;
}
.page-title {
  font-size: var(--ev-fs-16);
  font-weight: 600;
  color: var(--ev-text);
}

.tb-right {
  display: flex;
  align-items: center;
  gap: 18px;
}

.sys-status {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  font-size: var(--ev-fs-13);
  color: var(--ev-text-sub);
}
.sys-status .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ev-success);
  box-shadow: 0 0 8px rgba(52, 211, 153, 0.8);
  animation: pulse 2.2s ease-in-out infinite;
}
.sys-status .dot.offline {
  background: var(--ev-warning);
  box-shadow: 0 0 8px rgba(251, 191, 36, 0.7);
}
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.45; }
}

.mode-switch {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.mode-label {
  font-size: var(--ev-fs-13);
  color: var(--ev-text-sub);
}

.alert-badge :deep(.el-badge__content) {
  background: var(--ev-danger);
  border: none;
}

.clock {
  font-size: var(--ev-fs-14);
  color: var(--ev-text);
  letter-spacing: 0.5px;
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-sm);
  padding: 4px 10px;
}

.content {
  flex: 1;
  padding: 24px;
  position: relative;
  z-index: 1;
}

/* 页面切换动画 */
.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.fade-slide-enter-from {
  opacity: 0;
  transform: translateY(8px);
}
.fade-slide-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}
</style>
