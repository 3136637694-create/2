import type { AlertEvent, CameraInfo } from '@/types'

// ============ Mock 数据源（单一数据源，跨页一致） ============

export const mockCameras: CameraInfo[] = [
  {
    id: 1, name: '校门入口', location: '南门岗亭', source: 'rtsp://192.168.1.10:554/stream1',
    status: 'online', fps: 25, resolution: '1920x1080', enabled: true, lastSeen: '实时',
  },
  {
    id: 2, name: '教学楼大厅', location: '综合楼一层', source: 'rtsp://192.168.1.11:554/stream1',
    status: 'online', fps: 25, resolution: '1920x1080', enabled: true, lastSeen: '实时',
  },
  {
    id: 3, name: '实验室走廊', location: '实验楼三层', source: 'rtsp://192.168.1.12:554/stream1',
    status: 'reconnecting', fps: 0, resolution: '1920x1080', enabled: true, lastSeen: '02:13:45',
  },
  {
    id: 4, name: '工地东区塔吊', location: '东区塔吊顶', source: 'rtsp://192.168.1.20:554/stream1',
    status: 'online', fps: 15, resolution: '2560x1440', enabled: true, lastSeen: '实时',
  },
  {
    id: 5, name: '工地材料堆场', location: '北门堆场', source: 'rtsp://192.168.1.21:554/stream1',
    status: 'offline', fps: 0, resolution: '2560x1440', enabled: false, lastSeen: '07:12:30',
  },
  {
    id: 6, name: '超市入口', location: '正门闸机', source: 'rtsp://192.168.1.30:554/stream1',
    status: 'online', fps: 30, resolution: '1920x1080', enabled: true, lastSeen: '实时',
  },
  {
    id: 7, name: '停车场卡口', location: '北出口', source: 'rtsp://192.168.1.31:554/stream1',
    status: 'online', fps: 25, resolution: '1920x1080', enabled: true, lastSeen: '实时',
  },
  {
    id: 8, name: '地下车库', location: 'B2 出入口', source: 'rtsp://192.168.1.32:554/stream1',
    status: 'offline', fps: 0, resolution: '1920x1080', enabled: false, lastSeen: '昨天 23:58:12',
  },
]

// 事件类型 → 展示文案映射
export const EVENT_TYPE_MAP: Record<string, string> = {
  region_intrusion: '区域闯入',
  people_gathering: '人员聚集',
  left_object: '遗留物',
}

export const EVENT_LEVEL_MAP: Record<string, string> = {
  critical: '严重',
  warning: '警告',
  info: '提示',
}

// 历史告警事件（告警页初始数据；实时事件由模拟推送器追加）
function iso(dayOffset: number, hour: number, minute: number, second = 0): string {
  const d = new Date()
  d.setDate(d.getDate() - dayOffset)
  d.setHours(hour, minute, second, 0)
  return d.toISOString()
}

export const mockEvents: AlertEvent[] = [
  {
    id: 1001, cameraId: 2, cameraName: '教学楼大厅', type: 'region_intrusion', level: 'critical',
    message: '人员闯入禁止区域（北侧通道），已持续 12 秒',
    targets: [{ trackId: 3021, cls: 'person', confidence: 0.94 }], ts: iso(0, 8, 41, 12),
  },
  {
    id: 1002, cameraId: 6, cameraName: '超市入口', type: 'people_gathering', level: 'warning',
    message: '人员聚集（6 人）持续超过 30 秒，建议疏导',
    targets: [
      { trackId: 5120, cls: 'person', confidence: 0.91 },
      { trackId: 5123, cls: 'person', confidence: 0.88 },
      { trackId: 5125, cls: 'person', confidence: 0.83 },
    ], ts: iso(0, 7, 56, 40),
  },
  {
    id: 1003, cameraId: 4, cameraName: '工地东区塔吊', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（工程设备），持续停留 5 分钟',
    targets: [{ trackId: 9007, cls: 'object', confidence: 0.76 }], ts: iso(0, 7, 12, 3),
  },
  {
    id: 1004, cameraId: 1, cameraName: '校门入口', type: 'region_intrusion', level: 'warning',
    message: '外来人员越过闸机警戒线',
    targets: [{ trackId: 104, cls: 'person', confidence: 0.87 }], ts: iso(0, 6, 48, 55),
  },
  {
    id: 1005, cameraId: 7, cameraName: '停车场卡口', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（包裹），持续停留 8 分钟',
    targets: [{ trackId: 7702, cls: 'object', confidence: 0.72 }], ts: iso(1, 18, 30, 21),
  },
  {
    id: 1006, cameraId: 2, cameraName: '教学楼大厅', type: 'people_gathering', level: 'warning',
    message: '人员聚集（5 人）持续超过 30 秒',
    targets: [
      { trackId: 2901, cls: 'person', confidence: 0.9 },
      { trackId: 2908, cls: 'person', confidence: 0.86 },
    ], ts: iso(1, 17, 2, 46),
  },
  {
    id: 1007, cameraId: 6, cameraName: '超市入口', type: 'region_intrusion', level: 'critical',
    message: '人员闯入收银区内部通道',
    targets: [{ trackId: 5033, cls: 'person', confidence: 0.95 }], ts: iso(1, 16, 44, 9),
  },
  {
    id: 1008, cameraId: 4, cameraName: '工地东区塔吊', type: 'region_intrusion', level: 'critical',
    message: '人员闯入吊装作业警戒区',
    targets: [{ trackId: 9001, cls: 'person', confidence: 0.96 }], ts: iso(1, 15, 58, 33),
  },
  {
    id: 1009, cameraId: 1, cameraName: '校门入口', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（行李箱），持续停留 12 分钟',
    targets: [{ trackId: 180, cls: 'object', confidence: 0.69 }], ts: iso(1, 14, 3, 18),
  },
  {
    id: 1010, cameraId: 3, cameraName: '实验室走廊', type: 'region_intrusion', level: 'warning',
    message: '人员进入晚间封闭区域',
    targets: [{ trackId: 4106, cls: 'person', confidence: 0.85 }], ts: iso(2, 22, 47, 52),
  },
  {
    id: 1011, cameraId: 2, cameraName: '教学楼大厅', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（书包），持续停留 20 分钟',
    targets: [{ trackId: 2999, cls: 'object', confidence: 0.74 }], ts: iso(2, 19, 22, 7),
  },
  {
    id: 1012, cameraId: 7, cameraName: '停车场卡口', type: 'people_gathering', level: 'warning',
    message: '车辆聚集（7 辆）导致出口拥堵',
    targets: [
      { trackId: 7601, cls: 'vehicle', confidence: 0.93 },
      { trackId: 7602, cls: 'vehicle', confidence: 0.91 },
      { trackId: 7604, cls: 'vehicle', confidence: 0.89 },
    ], ts: iso(2, 16, 30, 25),
  },
  {
    id: 1013, cameraId: 6, cameraName: '超市入口', type: 'region_intrusion', level: 'warning',
    message: '人员越过购物车回收区警戒线',
    targets: [{ trackId: 5090, cls: 'person', confidence: 0.88 }], ts: iso(2, 13, 15, 44),
  },
  {
    id: 1014, cameraId: 4, cameraName: '工地东区塔吊', type: 'people_gathering', level: 'warning',
    message: '人员聚集（8 人）在吊装区域，疑似违章作业',
    targets: [
      { trackId: 9020, cls: 'person', confidence: 0.92 },
      { trackId: 9021, cls: 'person', confidence: 0.87 },
      { trackId: 9023, cls: 'person', confidence: 0.81 },
    ], ts: iso(3, 10, 5, 36),
  },
  {
    id: 1015, cameraId: 1, cameraName: '校门入口', type: 'region_intrusion', level: 'info',
    message: '人员短暂越线（< 3 秒），未构成违规',
    targets: [{ trackId: 231, cls: 'person', confidence: 0.82 }], ts: iso(3, 8, 50, 12),
  },
  {
    id: 1016, cameraId: 5, cameraName: '工地材料堆场', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（建材），持续停留 30 分钟',
    targets: [{ trackId: 9301, cls: 'object', confidence: 0.7 }], ts: iso(3, 7, 40, 55),
  },
  {
    id: 1017, cameraId: 2, cameraName: '教学楼大厅', type: 'region_intrusion', level: 'critical',
    message: '人员闯入实验室禁入区域',
    targets: [{ trackId: 2950, cls: 'person', confidence: 0.93 }], ts: iso(4, 21, 33, 28),
  },
  {
    id: 1018, cameraId: 7, cameraName: '停车场卡口', type: 'region_intrusion', level: 'warning',
    message: '车辆逆行进入出口通道',
    targets: [{ trackId: 7640, cls: 'vehicle', confidence: 0.9 }], ts: iso(4, 18, 12, 49),
  },
  {
    id: 1019, cameraId: 6, cameraName: '超市入口', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（购物袋），持续停留 15 分钟',
    targets: [{ trackId: 5177, cls: 'object', confidence: 0.71 }], ts: iso(4, 15, 6, 31),
  },
  {
    id: 1020, cameraId: 4, cameraName: '工地东区塔吊', type: 'region_intrusion', level: 'warning',
    message: '人员靠近高压线塔防护区边缘',
    targets: [{ trackId: 9044, cls: 'person', confidence: 0.84 }], ts: iso(5, 9, 28, 14),
  },
  {
    id: 1021, cameraId: 1, cameraName: '校门入口', type: 'people_gathering', level: 'warning',
    message: '人员聚集（5 人）在闸机前，排队溢出',
    targets: [
      { trackId: 301, cls: 'person', confidence: 0.89 },
      { trackId: 302, cls: 'person', confidence: 0.85 },
    ], ts: iso(5, 8, 15, 47),
  },
  {
    id: 1022, cameraId: 3, cameraName: '实验室走廊', type: 'left_object', level: 'info',
    message: '检测到疑似遗留物（试剂箱），持续停留 40 分钟',
    targets: [{ trackId: 4201, cls: 'object', confidence: 0.73 }], ts: iso(6, 23, 18, 2),
  },
  {
    id: 1023, cameraId: 7, cameraName: '停车场卡口', type: 'people_gathering', level: 'warning',
    message: '人员聚集（6 人）在岗亭前',
    targets: [
      { trackId: 7610, cls: 'person', confidence: 0.86 },
      { trackId: 7612, cls: 'person', confidence: 0.8 },
    ], ts: iso(6, 17, 44, 30),
  },
  {
    id: 1024, cameraId: 2, cameraName: '教学楼大厅', type: 'people_gathering', level: 'info',
    message: '人员聚集（4 人）短暂停留后散去',
    targets: [{ trackId: 2910, cls: 'person', confidence: 0.83 }], ts: iso(6, 14, 20, 9),
  },
  {
    id: 1025, cameraId: 6, cameraName: '超市入口', type: 'people_gathering', level: 'critical',
    message: '人员聚集（10 人）在入口，疑似拥堵事件',
    targets: [
      { trackId: 5200, cls: 'person', confidence: 0.92 },
      { trackId: 5201, cls: 'person', confidence: 0.9 },
      { trackId: 5203, cls: 'person', confidence: 0.88 },
      { trackId: 5205, cls: 'person', confidence: 0.85 },
    ], ts: iso(7, 12, 8, 51),
  },
  {
    id: 1026, cameraId: 1, cameraName: '校门入口', type: 'region_intrusion', level: 'warning',
    message: '人员翻越护栏警戒线',
    targets: [{ trackId: 344, cls: 'person', confidence: 0.89 }], ts: iso(7, 9, 55, 16),
  },
]
