import type {
  AlertEvent, Detection, DetClass, EventLevel, EventType, Metric,
} from '@/types'
import { EVENT_TYPE_MAP, mockCameras } from './data'

// ============ 模拟实时推送引擎 ============
// 模拟后端 /ws/monitor：每 800ms 推送检测帧，随机生成告警事件与性能指标。
// 接入真实后端时，整体由 src/api/ws.ts 的真实 WebSocket 取代。

interface SimTrack {
  id: number
  cls: DetClass
  x: number
  y: number
  w: number
  h: number
  vx: number
  vy: number
  age: number
  /** 静止目标（遗留物） */
  stationary: boolean
  history: { x: number; y: number }[]
}

interface SimState {
  tracks: Map<number, SimTrack>
  cooldown: Partial<Record<EventType, number>>
  intrusionCount: Map<number, number>
  gatheringCount: number
}

const TICK_MS = 800
const SPECTRUM: [DetClass, number][] = [
  ['person', 0.62],
  ['vehicle', 0.26],
  ['object', 0.12],
]

function rand(min: number, max: number): number {
  return min + Math.random() * (max - min)
}

function pickClass(): DetClass {
  const r = Math.random()
  let acc = 0
  for (const [cls, w] of SPECTRUM) {
    acc += w
    if (r <= acc) return cls
  }
  return 'person'
}

function levelFor(type: EventType, crowd: boolean): EventLevel {
  if (type === 'region_intrusion') return crowd ? 'critical' : 'warning'
  if (type === 'people_gathering') return crowd ? 'critical' : 'warning'
  return 'info'
}

export class Simulator {
  private states = new Map<number, SimState>()
  private nextTrackId = 100
  private nextEventId = 2000
  private timer: ReturnType<typeof setInterval> | null = null
  private started = false
  private droppedFrames = 0
  private latency = 42
  private detCount = 0

  onDetections: ((cameraId: number, items: Detection[]) => void) | null = null
  onEvent: ((event: AlertEvent) => void) | null = null
  onMetric: ((metric: Metric) => void) | null = null

  private stateOf(cameraId: number): SimState {
    let s = this.states.get(cameraId)
    if (!s) {
      s = { tracks: new Map(), cooldown: {}, intrusionCount: new Map(), gatheringCount: 0 }
      this.states.set(cameraId, s)
    }
    return s
  }

  start(): void {
    if (this.started) return
    this.started = true
    this.timer = setInterval(() => this.tick(), TICK_MS)
  }

  stop(): void {
    this.started = false
    if (this.timer) clearInterval(this.timer)
    this.timer = null
  }

  private spawnTrack(s: SimState): void {
    const cls = pickClass()
    const stationary = cls === 'object' && Math.random() < 0.7
    const w = cls === 'vehicle' ? rand(0.08, 0.16) : cls === 'person' ? rand(0.04, 0.09) : rand(0.05, 0.12)
    const h = cls === 'vehicle' ? rand(0.07, 0.13) : cls === 'person' ? rand(0.14, 0.22) : rand(0.04, 0.09)
    const x = rand(0.03, 0.8)
    const y = stationary ? rand(0.15, 0.75) : rand(0.05, 0.9)
    s.tracks.set(this.nextTrackId++, {
      id: this.nextTrackId - 1,
      cls,
      x,
      y,
      w,
      h,
      vx: stationary ? 0 : rand(-0.004, 0.004),
      vy: stationary ? 0 : rand(-0.004, 0.004),
      age: 0,
      stationary,
      history: [{ x, y }],
    })
  }

  private advance(s: SimState): void {
    for (const [id, t] of s.tracks) {
      if (!t.stationary) {
        t.x += t.vx
        t.y += t.vy
        // 轻微随机摆动，避免直线呆板
        if (Math.random() < 0.02) t.vx += rand(-0.001, 0.001)
        if (Math.random() < 0.02) t.vy += rand(-0.001, 0.001)
        // 边界内转向
        if (t.x < 0.02 || t.x + t.w > 0.98) t.vx = -t.vx
        if (t.y < 0.02 || t.y + t.h > 0.98) t.vy = -t.vy
      }
      t.age++
      if (t.history.length > 30) t.history.shift()
      t.history.push({ x: t.x + t.w / 2, y: t.y + t.h / 2 })
      // 静止遗留物保留更久，其余目标超过寿命移除
      const maxAge = t.stationary ? 900 : 260
      if (t.age > maxAge) s.tracks.delete(id)
    }
  }

  private maybeEvents(s: SimState, cameraId: number): AlertEvent[] {
    const now = Date.now()
    const ev: AlertEvent[] = []
    const cam = mockCameras.find((c) => c.id === cameraId) ?? { name: `摄像头 ${cameraId}` }
    const name = cam.name

    const inZone = (t: SimTrack) => {
      // 画面中下部为“禁入/警戒区域”
      const cx = t.x + t.w / 2
      const cy = t.y + t.h / 2
      return cy > 0.68 && cx > 0.3 && cx < 0.8
    }

    // 1) 区域闯入
    const intruders = [...s.tracks.values()].filter((t) => !t.stationary && inZone(t))
    for (const t of intruders) {
      const n = s.intrusionCount.get(t.id) ?? 0
      s.intrusionCount.set(t.id, n + 1)
      if (n === 9 && now > (s.cooldown.region_intrusion ?? 0)) {
        s.cooldown.region_intrusion = now + 20000
        ev.push({
          id: this.nextEventId++, cameraId, cameraName: name,
          type: 'region_intrusion',
          level: n > 20 ? 'critical' : 'warning',
          message: `人员闯入禁止区域（${name}），已持续 ${Math.round((n * TICK_MS) / 1000)} 秒`,
          targets: [{ trackId: t.id, cls: t.cls, confidence: rand(0.8, 0.97) }],
          ts: new Date(now).toISOString(),
        })
      }
    }

    // 2) 人员聚集
    const people = [...s.tracks.values()].filter((t) => t.cls === 'person' && !t.stationary)
    let crowd = 0
    for (let i = 0; i < people.length; i++) {
      let near = 1
      for (let j = 0; j < people.length; j++) {
        if (i === j) continue
        const dx = people[i].x - people[j].x
        const dy = people[i].y - people[j].y
        if (dx * dx + dy * dy < 0.02) near++
      }
      crowd = Math.max(crowd, near)
    }
    if (crowd >= 5) s.gatheringCount++
    else s.gatheringCount = Math.max(0, s.gatheringCount - 1)
    if (crowd >= 5 && s.gatheringCount >= 10 && now > (s.cooldown.people_gathering ?? 0)) {
      s.cooldown.people_gathering = now + 30000
      const targets = people
        .sort((a, b) => b.age - a.age)
        .slice(0, 4)
        .map((t) => ({ trackId: t.id, cls: t.cls, confidence: rand(0.78, 0.95) }))
      ev.push({
        id: this.nextEventId++, cameraId, cameraName: name,
        type: 'people_gathering',
        level: levelFor('people_gathering', crowd >= 8),
        message: `人员聚集（${crowd} 人）持续超过 30 秒，建议关注`,
        targets,
        ts: new Date(now).toISOString(),
      })
    }

    // 3) 遗留物
    for (const t of s.tracks.values()) {
      if (t.stationary && t.age === 30 && now > (s.cooldown.left_object ?? 0)) {
        s.cooldown.left_object = now + 40000
        ev.push({
          id: this.nextEventId++, cameraId, cameraName: name,
          type: 'left_object',
          level: 'info',
          message: `检测到疑似遗留物，持续停留 ${Math.round((t.age * TICK_MS) / 1000)} 秒`,
          targets: [{ trackId: t.id, cls: 'object', confidence: rand(0.66, 0.8) }],
          ts: new Date(now).toISOString(),
        })
      }
    }
    return ev
  }

  private tick(): void {
    for (const cam of mockCameras) {
      if (!cam.enabled || cam.status !== 'online') continue
      const s = this.stateOf(cam.id)
      if (s.tracks.size < 4 && Math.random() < 0.6) this.spawnTrack(s)
      this.advance(s)

      const items: Detection[] = []
      let id = 1
      for (const t of s.tracks.values()) {
        const confidence = t.stationary ? rand(0.62, 0.8) : rand(0.75, 0.97)
        items.push({
          id: id++,
          cameraId: cam.id,
          ts: new Date().toISOString(),
          trackId: t.id,
          cls: t.cls,
          confidence: +confidence.toFixed(2),
          bbox: [+t.x.toFixed(3), +t.y.toFixed(3), +(t.x + t.w).toFixed(3), +(t.y + t.h).toFixed(3)],
        })
      }
      if (items.length) {
        this.detCount++
        this.onDetections?.(cam.id, items)
      } else if (Math.random() < 0.2) {
        this.droppedFrames++
      }

      for (const e of this.maybeEvents(s, cam.id)) this.onEvent?.(e)
    }

    // 性能指标：延迟随机游走 + 偶发尖峰
    this.latency = Math.max(
      28,
      Math.min(140, this.latency + rand(-6, 6) + (Math.random() < 0.05 ? rand(60, 180) : 0)),
    )
    if (Math.random() < 0.25) this.droppedFrames++
    const queueUsage = Math.min(
      100,
      Math.max(8, 38 + Math.sin(Date.now() / 5000) * 12 + (this.latency > 110 ? rand(10, 25) : rand(-4, 4))),
    )
    this.onMetric?.({
      ts: Date.now(),
      e2eLatencyMs: +this.latency.toFixed(1),
      droppedFrames: this.droppedFrames,
      queueCapacity: 100,
      queueUsage: +queueUsage.toFixed(1),
      fps: +rand(18, 30).toFixed(1),
      detectionMs: +rand(8, 24).toFixed(1),
    })
  }
}

// 事件类型中文名（供实时告警流展示）
export function eventTypeText(type: EventType): string {
  return EVENT_TYPE_MAP[type] ?? type
}

export const simulator = new Simulator()
