import { createRouter, createWebHistory } from 'vue-router'
import AppLayout from '@/layout/AppLayout.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      component: AppLayout,
      children: [
        { path: '', redirect: '/monitor' },
        {
          path: 'monitor', name: 'monitor',
          component: () => import('@/views/MonitorView.vue'),
          meta: { title: '实时监控' },
        },
        {
          path: 'cameras', name: 'cameras',
          component: () => import('@/views/CamerasView.vue'),
          meta: { title: '摄像头管理' },
        },
        {
          path: 'alerts', name: 'alerts',
          component: () => import('@/views/AlertsView.vue'),
          meta: { title: '告警事件' },
        },
        {
          path: 'metrics', name: 'metrics',
          component: () => import('@/views/MetricsView.vue'),
          meta: { title: '系统指标' },
        },
      ],
    },
    { path: '/:pathMatch(.*)*', redirect: '/monitor' },
  ],
})

export default router
