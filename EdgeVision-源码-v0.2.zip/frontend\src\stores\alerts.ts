import { defineStore } from 'pinia'
import { reactive, ref } from 'vue'
import type { AlertEvent, EventLevel, EventType } from '@/types'
import { getAlerts } from '@/api'

export const useAlertsStore = defineStore('alerts', () => {
  const filters = reactive<{
    type: EventType | 'all'
    level: EventLevel | 'all'
    cameraId?: number
  }>({ type: 'all', level: 'all' })

  const page = ref(1)
  const pageSize = ref(10)
  const items = ref<AlertEvent[]>([])
  const total = ref(0)
  const loading = ref(false)

  /** 实时告警流（监控页右侧面板 + 顶栏未读计数） */
  const live = ref<AlertEvent[]>([])
  const liveUnread = ref(0)

  async function load(): Promise<void> {
    loading.value = true
    try {
      const res = await getAlerts({
        type: filters.type,
        level: filters.level,
        cameraId: filters.cameraId,
        page: page.value,
        pageSize: pageSize.value,
      })
      items.value = res.items
      total.value = res.total
    } finally {
      loading.value = false
    }
  }

  function pushLive(e: AlertEvent): void {
    live.value.unshift(e)
    if (live.value.length > 60) live.value.pop()
    liveUnread.value++
  }

  function clearUnread(): void {
    liveUnread.value = 0
  }

  return { filters, page, pageSize, items, total, loading, live, liveUnread, load, pushLive, clearUnread }
})
