import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { SystemStats } from '@/types'
import { dataMode, setDataMode, type DataMode } from '@/config'
import { getSystemStats } from '@/api'

export const useAppStore = defineStore('app', () => {
  const now = ref(new Date())
  const mode = ref<DataMode>(dataMode.value)
  const sidebarCollapsed = ref(false)
  const stats = ref<SystemStats | null>(null)
  const statsLoading = ref(false)

  // 顶栏实时时钟
  setInterval(() => {
    now.value = new Date()
  }, 1000)

  function switchMode(m: DataMode): void {
    setDataMode(m)
    mode.value = m
  }

  async function loadStats(): Promise<void> {
    statsLoading.value = true
    try {
      stats.value = await getSystemStats()
    } finally {
      statsLoading.value = false
    }
  }

  return { now, mode, sidebarCollapsed, stats, statsLoading, switchMode, loadStats }
})
