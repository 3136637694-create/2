import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import type { CameraInfo } from '@/types'
import { addCamera as apiAdd, deleteCamera as apiDelete, getCameras, updateCamera as apiUpdate } from '@/api'

export const useCamerasStore = defineStore('cameras', () => {
  const list = ref<CameraInfo[]>([])
  const loading = ref(false)

  const onlineCount = computed(() => list.value.filter((c) => c.status === 'online').length)
  const offlineCount = computed(() => list.value.filter((c) => c.status === 'offline').length)
  const reconnectingCount = computed(() => list.value.filter((c) => c.status === 'reconnecting').length)

  async function load(): Promise<void> {
    loading.value = true
    try {
      list.value = await getCameras()
    } finally {
      loading.value = false
    }
  }

  async function add(payload: Omit<CameraInfo, 'id' | 'status' | 'lastSeen'>): Promise<void> {
    const cam = await apiAdd(payload)
    list.value.push(cam)
  }

  async function update(id: number, payload: Partial<CameraInfo>): Promise<void> {
    const cam = await apiUpdate(id, payload)
    const idx = list.value.findIndex((c) => c.id === id)
    if (idx >= 0) list.value[idx] = cam
  }

  async function remove(id: number): Promise<void> {
    await apiDelete(id)
    list.value = list.value.filter((c) => c.id !== id)
  }

  function byId(id: number): CameraInfo | undefined {
    return list.value.find((c) => c.id === id)
  }

  return { list, loading, onlineCount, offlineCount, reconnectingCount, load, add, update, remove, byId }
})
