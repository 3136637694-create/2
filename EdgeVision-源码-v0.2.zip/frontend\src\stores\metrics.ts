import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { Metric } from '@/types'
import { getMetrics } from '@/api'
import { subscribeMonitor } from '@/api/ws'

const MAX_POINTS = 120

export const useMetricsStore = defineStore('metrics', () => {
  const series = ref<Metric[]>([])
  const loading = ref(false)
  const latest = ref<Metric | null>(null)
  const droppedFrames = ref(0)
  let unsub: (() => void) | null = null

  function push(m: Metric): void {
    latest.value = m
    droppedFrames.value = m.droppedFrames
    series.value.push(m)
    if (series.value.length > MAX_POINTS) series.value.shift()
  }

  async function load(): Promise<void> {
    loading.value = true
    try {
      const data = await getMetrics()
      series.value = data
      latest.value = data[data.length - 1] ?? null
      droppedFrames.value = latest.value?.droppedFrames ?? 0
    } finally {
      loading.value = false
    }
  }

  function start(): void {
    if (unsub) return
    unsub = subscribeMonitor((f) => {
      if (f.kind === 'metric') push(f.metric)
    })
  }

  function stop(): void {
    unsub?.()
    unsub = null
  }

  return { series, loading, latest, droppedFrames, push, load, start, stop }
})
