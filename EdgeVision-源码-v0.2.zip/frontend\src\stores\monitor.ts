import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { Detection } from '@/types'
import { subscribeMonitor } from '@/api/ws'

export interface HistoryPoint {
  x: number
  y: number
}

export const useMonitorStore = defineStore('monitor', () => {
  const currentCameraId = ref(1)
  const detections = ref<Detection[]>([])
  const trackHistory = ref<Map<number, HistoryPoint[]>>(new Map())
  const connected = ref(false)
  const lastFrameAt = ref<number | null>(null)
  const showBoxes = ref(true)
  const showIds = ref(true)
  const showTrails = ref(true)

  let unsub: (() => void) | null = null

  function handleFrame(cameraId: number, items: Detection[]): void {
    if (cameraId !== currentCameraId.value) return
    detections.value = items
    lastFrameAt.value = Date.now()

    const next = new Map(trackHistory.value)
    for (const d of items) {
      const pts = next.get(d.trackId) ?? []
      pts.push({ x: (d.bbox[0] + d.bbox[2]) / 2, y: (d.bbox[1] + d.bbox[3]) / 2 })
      if (pts.length > 40) pts.shift()
      next.set(d.trackId, pts)
    }
    const alive = new Set(items.map((i) => i.trackId))
    for (const k of [...next.keys()]) if (!alive.has(k)) next.delete(k)
    trackHistory.value = next
  }

  function start(): void {
    if (unsub) return
    unsub = subscribeMonitor((f) => {
      if (f.kind === 'detections') handleFrame(f.cameraId, f.items)
    })
    connected.value = true
  }

  function stop(): void {
    unsub?.()
    unsub = null
    connected.value = false
  }

  function selectCamera(id: number): void {
    currentCameraId.value = id
    detections.value = []
    trackHistory.value = new Map()
    lastFrameAt.value = null
  }

  return {
    currentCameraId, detections, trackHistory, connected, lastFrameAt,
    showBoxes, showIds, showTrails, start, stop, selectCamera,
  }
})
