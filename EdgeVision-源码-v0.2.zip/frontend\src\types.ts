// ============ 领域模型（与后端 Pydantic 模型一一对应） ============

export type CameraStatus = 'online' | 'offline' | 'reconnecting'

export interface CameraInfo {
  id: number
  name: string
  location: string
  /** RTSP / 本地摄像头源地址 */
  source: string
  status: CameraStatus
  fps: number
  resolution: string
  enabled: boolean
  /** 最近一次收到帧的时间，格式 HH:mm:ss */
  lastSeen: string
}

export type DetClass = 'person' | 'vehicle' | 'object'

export interface Detection {
  id: number
  cameraId: number
  ts: string
  /** SORT 分配的目标跟踪 ID */
  trackId: number
  cls: DetClass
  confidence: number
  /** 归一化检测框 [x1, y1, x2, y2]，取值 0~1 */
  bbox: [number, number, number, number]
}

export type EventType = 'region_intrusion' | 'people_gathering' | 'left_object'
export type EventLevel = 'critical' | 'warning' | 'info'

export interface EventTarget {
  trackId: number
  cls: DetClass
  confidence: number
}

export interface AlertEvent {
  id: number
  cameraId: number
  cameraName: string
  type: EventType
  level: EventLevel
  message: string
  targets: EventTarget[]
  /** ISO 时间 */
  ts: string
}

export interface Metric {
  ts: number
  /** 端到端延迟 ms */
  e2eLatencyMs: number
  /** 累计丢帧数 */
  droppedFrames: number
  /** 队列容量 */
  queueCapacity: number
  /** 队列当前占用 */
  queueUsage: number
  /** 实时帧率 */
  fps: number
  /** 单帧推理耗时 ms */
  detectionMs: number
}

export interface SystemStats {
  camerasTotal: number
  camerasOnline: number
  eventsToday: number
  criticalEvents: number
  avgLatencyMs: number
  droppedFrames: number
  queueUsage: number
  uptimeSec: number
  version: string
  model: string
}

/** WebSocket 实时帧（后端 /ws/monitor 推送格式） */
export type WsFrame =
  | { kind: 'detections'; cameraId: number; ts: string; items: Detection[] }
  | { kind: 'event'; event: AlertEvent }
  | { kind: 'metric'; metric: Metric }
