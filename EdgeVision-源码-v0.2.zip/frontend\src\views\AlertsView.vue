<template>
  <div class="alerts-page">
    <!-- ======== 筛选栏 ======== -->
    <div class="card filter-bar">
      <div class="filter-item">
        <span class="filter-label">类型</span>
        <el-select v-model="alerts.filters.type" style="width: 130px" @change="onFilter">
          <el-option label="全部类型" value="all" />
          <el-option v-for="(text, key) in TYPE_MAP" :key="key" :label="text" :value="key" />
        </el-select>
      </div>
      <div class="filter-item">
        <span class="filter-label">等级</span>
        <el-select v-model="alerts.filters.level" style="width: 110px" @change="onFilter">
          <el-option label="全部等级" value="all" />
          <el-option label="严重" value="critical" />
          <el-option label="警告" value="warning" />
          <el-option label="提示" value="info" />
        </el-select>
      </div>
      <div class="filter-item">
        <span class="filter-label">摄像头</span>
        <el-select
          v-model="alerts.filters.cameraId"
          style="width: 160px"
          clearable
          placeholder="全部摄像头"
          @change="onFilter"
        >
          <el-option v-for="c in cameras.list" :key="c.id" :label="c.name" :value="c.id" />
        </el-select>
      </div>
      <div class="filter-right">
        <span class="mono total-tip">共 {{ alerts.total }} 条记录</span>
        <el-button :icon="Refresh" :loading="alerts.loading" @click="alerts.load()">刷新</el-button>
      </div>
    </div>

    <!-- ======== 告警表格 ======== -->
    <div class="card">
      <el-table :data="alerts.items" v-loading="alerts.loading" class="alert-table" row-key="id">
        <el-table-column label="ID" width="70">
          <template #default="{ row }">
            <span class="mono id-col">#{{ row.id }}</span>
          </template>
        </el-table-column>

        <el-table-column label="时间" width="150">
          <template #default="{ row }">
            <span class="mono">{{ fmtDateTime(row.ts) }}</span>
          </template>
        </el-table-column>

        <el-table-column label="摄像头" min-width="110" prop="cameraName" />

        <el-table-column label="类型" width="110">
          <template #default="{ row }">
            <span class="type-text">{{ TYPE_MAP[row.type] ?? row.type }}</span>
          </template>
        </el-table-column>

        <el-table-column label="等级" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="levelType(row.level)" size="small">{{ LEVEL_MAP[row.level] }}</el-tag>
          </template>
        </el-table-column>

        <el-table-column label="事件描述" min-width="260">
          <template #default="{ row }">
            <span class="msg-text" :title="row.message">{{ row.message }}</span>
          </template>
        </el-table-column>

        <el-table-column label="关联目标" width="110" align="center">
          <template #default="{ row }">
            <span class="mono target-count">{{ row.targets.length }} 个</span>
          </template>
        </el-table-column>

        <el-table-column label="操作" width="90" align="center">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="openDetail(row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination
          v-model:current-page="alerts.page"
          v-model:page-size="alerts.pageSize"
          :total="alerts.total"
          :page-sizes="[10, 20, 50]"
          layout="total, sizes, prev, pager, next"
          background
          @change="alerts.load"
        />
      </div>
    </div>

    <!-- ======== 详情抽屉 ======== -->
    <el-drawer v-model="drawerVisible" title="告警详情" size="420px">
      <template v-if="detail">
        <div class="detail-head">
          <el-tag :type="levelType(detail.level)" size="large">{{ LEVEL_MAP[detail.level] }}</el-tag>
          <span class="detail-type">{{ TYPE_MAP[detail.type] ?? detail.type }}</span>
        </div>
        <p class="detail-msg">{{ detail.message }}</p>

        <dl class="detail-meta">
          <div class="meta-row">
            <dt>事件 ID</dt><dd class="mono">{{ detail.id }}</dd>
          </div>
          <div class="meta-row">
            <dt>时间</dt><dd class="mono">{{ fmtDateTime(detail.ts) }}</dd>
          </div>
          <div class="meta-row">
            <dt>摄像头</dt><dd>{{ detail.cameraName }}（#{{ detail.cameraId }}）</dd>
          </div>
        </dl>

        <div class="targets-title">关联目标（{{ detail.targets.length }}）</div>
        <ul class="target-list">
          <li v-for="t in detail.targets" :key="t.trackId" class="target-item">
            <span class="cls-dot" :style="{ background: clsColor(t.cls) }" />
            <span>ID {{ String(t.trackId).padStart(4, '0') }}</span>
            <span class="mono sub">{{ clsText(t.cls) }} · {{ t.confidence.toFixed(2) }}</span>
          </li>
        </ul>
      </template>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import type { AlertEvent, DetClass, EventLevel } from '@/types'
import { useAlertsStore } from '@/stores/alerts'
import { useCamerasStore } from '@/stores/cameras'
import { subscribeMonitor } from '@/api/ws'
import { EVENT_LEVEL_MAP, EVENT_TYPE_MAP } from '@/mock/data'
import { fmtDateTime } from '@/utils/format'

const alerts = useAlertsStore()
const cameras = useCamerasStore()

const TYPE_MAP = EVENT_TYPE_MAP
const LEVEL_MAP = EVENT_LEVEL_MAP

const drawerVisible = ref(false)
const detail = ref<AlertEvent | null>(null)

let unsub: (() => void) | null = null

function levelType(lv: EventLevel): 'danger' | 'warning' | 'info' {
  return lv === 'critical' ? 'danger' : lv === 'warning' ? 'warning' : 'info'
}

function clsColor(cls: DetClass): string {
  return { person: '#22D3EE', vehicle: '#FBBF24', object: '#34D399' }[cls] ?? '#22D3EE'
}
function clsText(cls: DetClass): string {
  return { person: '人', vehicle: '车', object: '物' }[cls] ?? cls
}

function onFilter(): void {
  alerts.page = 1
  alerts.load()
}

function openDetail(row: AlertEvent): void {
  detail.value = row
  drawerVisible.value = true
}

function matchesFilter(e: AlertEvent): boolean {
  if (alerts.filters.type !== 'all' && e.type !== alerts.filters.type) return false
  if (alerts.filters.level !== 'all' && e.level !== alerts.filters.level) return false
  if (alerts.filters.cameraId && e.cameraId !== alerts.filters.cameraId) return false
  return true
}

onMounted(() => {
  cameras.load()
  alerts.load()
  // 实时事件：命中当前筛选时即时插入列表
  unsub = subscribeMonitor((f) => {
    if (f.kind !== 'event') return
    alerts.pushLive(f.event)
    if (matchesFilter(f.event)) {
      alerts.items.unshift(f.event)
      alerts.total++
    }
  })
})

onBeforeUnmount(() => {
  unsub?.()
})
</script>

<style scoped>
.alerts-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.card {
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-lg);
  padding: 14px 16px;
  box-shadow: var(--ev-shadow-md);
}

.filter-bar {
  display: flex;
  align-items: center;
  gap: 20px;
  flex-wrap: wrap;
}
.filter-item {
  display: flex;
  align-items: center;
  gap: 8px;
}
.filter-label {
  font-size: var(--ev-fs-13);
  color: var(--ev-text-sub);
}
.filter-right {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 14px;
}
.total-tip {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}

.alert-table :deep(.el-table) {
  --el-table-bg-color: transparent;
  --el-table-tr-bg-color: transparent;
  --el-table-header-bg-color: rgba(30, 40, 56, 0.5);
  --el-table-border-color: var(--ev-border);
  --el-table-row-hover-bg-color: rgba(34, 211, 238, 0.05);
}

.id-col {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}
.type-text {
  color: var(--ev-text);
}
.msg-text {
  color: var(--ev-text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: block;
  max-width: 100%;
}
.target-count {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}

.pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 14px;
}

/* 详情抽屉 */
.detail-head {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}
.detail-type {
  font-size: var(--ev-fs-16);
  font-weight: 600;
}
.detail-msg {
  font-size: var(--ev-fs-14);
  color: var(--ev-text);
  line-height: 1.6;
  margin-bottom: 18px;
}
.detail-meta {
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-md);
  overflow: hidden;
  margin-bottom: 18px;
}
.meta-row {
  display: flex;
  padding: 9px 12px;
  border-bottom: 1px solid var(--ev-border);
  font-size: var(--ev-fs-13);
}
.meta-row:last-child {
  border-bottom: none;
}
.meta-row dt {
  width: 80px;
  color: var(--ev-text-sub);
  flex: none;
}
.meta-row dd {
  flex: 1;
  color: var(--ev-text);
}
.targets-title {
  font-size: var(--ev-fs-14);
  font-weight: 600;
  margin-bottom: 8px;
}
.target-list {
  list-style: none;
}
.target-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 4px;
  border-bottom: 1px solid rgba(30, 40, 56, 0.5);
  font-size: var(--ev-fs-13);
  color: var(--ev-text);
}
.target-item:last-child {
  border-bottom: none;
}
.target-item .sub {
  color: var(--ev-text-sub);
  font-size: var(--ev-fs-12);
}
.cls-dot {
  width: 8px;
  height: 8px;
  border-radius: 2px;
  flex: none;
}
</style>
