<template>
  <div class="cameras-page">
    <!-- ======== 概览统计 ======== -->
    <div class="stat-row">
      <div class="stat-card">
        <span class="stat-num mono">{{ cameras.list.length }}</span>
        <span class="stat-label">摄像头总数</span>
      </div>
      <div class="stat-card ok">
        <span class="stat-num mono">{{ cameras.onlineCount }}</span>
        <span class="stat-label">在线</span>
      </div>
      <div class="stat-card warn">
        <span class="stat-num mono">{{ cameras.reconnectingCount }}</span>
        <span class="stat-label">重连中</span>
      </div>
      <div class="stat-card err">
        <span class="stat-num mono">{{ cameras.offlineCount }}</span>
        <span class="stat-label">离线</span>
      </div>
      <div class="stat-actions">
        <el-button type="primary" :icon="Plus" @click="openCreate">新增摄像头</el-button>
        <el-button :icon="Refresh" :loading="cameras.loading" @click="cameras.load()">刷新</el-button>
      </div>
    </div>

    <!-- ======== 摄像头表格 ======== -->
    <div class="card">
      <el-table :data="cameras.list" v-loading="cameras.loading" class="cam-table" row-key="id">
        <el-table-column label="ID" width="70">
          <template #default="{ row }">
            <span class="mono id-col">#{{ String(row.id).padStart(3, '0') }}</span>
          </template>
        </el-table-column>

        <el-table-column label="名称" min-width="130">
          <template #default="{ row }">
            <span class="cam-name">{{ row.name }}</span>
          </template>
        </el-table-column>

        <el-table-column label="位置" min-width="110" prop="location" />

        <el-table-column label="视频源" min-width="230">
          <template #default="{ row }">
            <span class="mono source" :title="row.source">{{ row.source }}</span>
          </template>
        </el-table-column>

        <el-table-column label="状态" width="90" align="center">
          <template #default="{ row }">
            <el-tag :type="statusType(row.status)" size="small">{{ statusText(row.status) }}</el-tag>
          </template>
        </el-table-column>

        <el-table-column label="分辨率" width="110" align="center">
          <template #default="{ row }">
            <span class="mono">{{ row.resolution }}</span>
          </template>
        </el-table-column>

        <el-table-column label="FPS" width="70" align="center">
          <template #default="{ row }">
            <span class="mono">{{ row.fps }}</span>
          </template>
        </el-table-column>

        <el-table-column label="最近帧" width="110">
          <template #default="{ row }">
            <span class="mono last-seen">{{ row.lastSeen }}</span>
          </template>
        </el-table-column>

        <el-table-column label="启用" width="80" align="center">
          <template #default="{ row }">
            <el-switch
              :model-value="row.enabled"
              size="small"
              :disabled="row.status === 'offline'"
              @update:model-value="(v: string | number | boolean) => toggleEnabled(row, v)"
            />
          </template>
        </el-table-column>

        <el-table-column label="操作" width="120" align="center" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" size="small" @click="openEdit(row)">编辑</el-button>
            <el-button link type="danger" size="small" @click="onDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- ======== 新增 / 编辑弹窗 ======== -->
    <el-dialog
      v-model="dialogVisible"
      :title="editing ? '编辑摄像头' : '新增摄像头'"
      width="520px"
      destroy-on-close
    >
      <el-form ref="formRef" :model="form" :rules="rules" label-width="86px" label-position="right">
        <el-form-item label="名称" prop="name">
          <el-input v-model="form.name" placeholder="如：校门入口" maxlength="20" show-word-limit />
        </el-form-item>
        <el-form-item label="位置" prop="location">
          <el-input v-model="form.location" placeholder="如：南门岗亭" maxlength="30" />
        </el-form-item>
        <el-form-item label="视频源" prop="source">
          <el-input v-model="form.source" placeholder="rtsp://192.168.x.x:554/stream1 或 0（本地摄像头）" />
        </el-form-item>
        <el-form-item label="分辨率" prop="resolution">
          <el-select v-model="form.resolution">
            <el-option label="1920x1080" value="1920x1080" />
            <el-option label="2560x1440" value="2560x1440" />
            <el-option label="1280x720" value="1280x720" />
          </el-select>
        </el-form-item>
        <el-form-item label="FPS" prop="fps">
          <el-input-number v-model="form.fps" :min="1" :max="60" />
        </el-form-item>
        <el-form-item label="启用">
          <el-switch v-model="form.enabled" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="onSave">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox, type FormInstance, type FormRules } from 'element-plus'
import { Plus, Refresh } from '@element-plus/icons-vue'
import { useCamerasStore } from '@/stores/cameras'
import type { CameraInfo, CameraStatus } from '@/types'

const cameras = useCamerasStore()

const dialogVisible = ref(false)
const editing = ref<CameraInfo | null>(null)
const saving = ref(false)
const formRef = ref<FormInstance>()
const form = reactive({
  name: '',
  location: '',
  source: '',
  resolution: '1920x1080',
  fps: 25,
  enabled: true,
})

const rules: FormRules = {
  name: [{ required: true, message: '请输入名称', trigger: 'blur' }],
  location: [{ required: true, message: '请输入位置', trigger: 'blur' }],
  source: [{ required: true, message: '请输入视频源地址', trigger: 'blur' }],
  resolution: [{ required: true, message: '请选择分辨率', trigger: 'change' }],
}

function statusType(s: CameraStatus): 'success' | 'danger' | 'warning' {
  return s === 'online' ? 'success' : s === 'offline' ? 'danger' : 'warning'
}
function statusText(s: CameraStatus): string {
  return s === 'online' ? '在线' : s === 'offline' ? '离线' : '重连中'
}

function openCreate(): void {
  editing.value = null
  form.name = ''
  form.location = ''
  form.source = ''
  form.resolution = '1920x1080'
  form.fps = 25
  form.enabled = true
  dialogVisible.value = true
}

function openEdit(row: CameraInfo): void {
  editing.value = row
  form.name = row.name
  form.location = row.location
  form.source = row.source
  form.resolution = row.resolution
  form.fps = row.fps
  form.enabled = row.enabled
  dialogVisible.value = true
}

async function onSave(): Promise<void> {
  const ok = await formRef.value?.validate().catch(() => false)
  if (!ok) return
  saving.value = true
  try {
    if (editing.value) {
      await cameras.update(editing.value.id, { ...form })
      ElMessage.success('摄像头已更新')
    } else {
      await cameras.add({ ...form })
      ElMessage.success('摄像头已添加')
    }
    dialogVisible.value = false
  } finally {
    saving.value = false
  }
}

async function toggleEnabled(row: CameraInfo, v: string | number | boolean): Promise<void> {
  await cameras.update(row.id, { enabled: Boolean(v) })
  ElMessage.success(v ? '已启用' : '已停用')
}

async function onDelete(row: CameraInfo): Promise<void> {
  try {
    await ElMessageBox.confirm(
      `删除后摄像头「${row.name}」将从系统移除，历史告警记录保留。确认删除？`,
      '删除确认',
      { type: 'warning', confirmButtonText: '删除', cancelButtonText: '取消' },
    )
  } catch {
    return
  }
  await cameras.remove(row.id)
  ElMessage.success('已删除')
}

onMounted(() => {
  cameras.load()
})
</script>

<style scoped>
.cameras-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.stat-row {
  display: flex;
  align-items: stretch;
  gap: 12px;
  flex-wrap: wrap;
}

.stat-card {
  flex: 1;
  min-width: 130px;
  max-width: 170px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
  padding: 14px 18px;
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-md);
  box-shadow: var(--ev-shadow-sm);
}
.stat-card.ok { border-top: 2px solid var(--ev-success); }
.stat-card.warn { border-top: 2px solid var(--ev-warning); }
.stat-card.err { border-top: 2px solid var(--ev-danger); }

.stat-num {
  font-size: var(--ev-fs-24);
  font-weight: 700;
  color: var(--ev-text);
}
.stat-label {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}

.stat-actions {
  flex: 1;
  display: flex;
  align-items: flex-end;
  justify-content: flex-end;
  gap: 10px;
}

.card {
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-lg);
  padding: 14px 16px;
  box-shadow: var(--ev-shadow-md);
}

.cam-table :deep(.el-table) {
  --el-table-bg-color: transparent;
  --el-table-tr-bg-color: transparent;
  --el-table-header-bg-color: rgba(30, 40, 56, 0.5);
  --el-table-border-color: var(--ev-border);
  --el-table-row-hover-bg-color: rgba(34, 211, 238, 0.05);
}

.cam-name {
  font-weight: 600;
  color: var(--ev-text);
}
.id-col {
  color: var(--ev-text-sub);
  font-size: var(--ev-fs-12);
}
.source {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: block;
  max-width: 100%;
}
.last-seen {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}
</style>
