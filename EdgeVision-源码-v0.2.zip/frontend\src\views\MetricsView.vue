<template>
  <div class="metrics-page">
    <!-- ======== 统计卡片 ======== -->
    <div class="stat-row">
      <div class="stat-card">
        <span class="stat-num mono">{{ app.stats?.camerasOnline ?? '--' }}<i>/{{ app.stats?.camerasTotal ?? '--' }}</i></span>
        <span class="stat-label">摄像头在线</span>
      </div>
      <div class="stat-card">
        <span class="stat-num mono">{{ metrics.droppedFrames }}</span>
        <span class="stat-label">累计丢帧</span>
      </div>
      <div class="stat-card">
        <span class="stat-num mono">{{ (metrics.latest?.e2eLatencyMs ?? 0).toFixed(1) }}<i>ms</i></span>
        <span class="stat-label">端到端延迟</span>
      </div>
      <div class="stat-card">
        <span class="stat-num mono">{{ (metrics.latest?.queueUsage ?? 0).toFixed(0) }}<i>%</i></span>
        <span class="stat-label">队列占用</span>
      </div>
    </div>

    <!-- ======== 折线图 ======== -->
    <div class="chart-grid">
      <div class="card chart-card">
        <div class="card-title">端到端延迟</div>
        <MetricLine :data="metrics.series" field="e2eLatencyMs" title="延迟" unit="ms" color="#22D3EE" />
      </div>
      <div class="card chart-card">
        <div class="card-title">队列占用</div>
        <MetricLine :data="metrics.series" field="queueUsage" title="占用率" unit="%" color="#FBBF24" />
      </div>
      <div class="card chart-card">
        <div class="card-title">累计丢帧</div>
        <MetricLine :data="metrics.series" field="droppedFrames" title="丢帧" unit="帧" color="#F87171" />
      </div>
    </div>

    <!-- ======== 系统信息 ======== -->
    <div class="card sys-card">
      <div class="card-title">系统信息</div>
      <div class="sys-grid">
        <div class="sys-item">
          <span class="sys-key">检测模型</span>
          <span class="sys-val mono">{{ app.stats?.model ?? '--' }}</span>
        </div>
        <div class="sys-item">
          <span class="sys-key">系统版本</span>
          <span class="sys-val mono">v{{ app.stats?.version ?? '--' }}</span>
        </div>
        <div class="sys-item">
          <span class="sys-key">运行时长</span>
          <span class="sys-val mono">{{ fmtUptime(app.stats?.uptimeSec ?? 0) }}</span>
        </div>
        <div class="sys-item">
          <span class="sys-key">今日事件</span>
          <span class="sys-val mono">{{ app.stats?.eventsToday ?? '--' }} 条</span>
        </div>
        <div class="sys-item">
          <span class="sys-key">严重事件</span>
          <span class="sys-val mono danger">{{ app.stats?.criticalEvents ?? '--' }} 条</span>
        </div>
        <div class="sys-item">
          <span class="sys-key">队列容量</span>
          <span class="sys-val mono">{{ metrics.latest?.queueCapacity ?? 100 }} 帧</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted } from 'vue'
import MetricLine from '@/components/MetricLine.vue'
import { useMetricsStore } from '@/stores/metrics'
import { useAppStore } from '@/stores/app'
import { fmtUptime } from '@/utils/format'

const metrics = useMetricsStore()
const app = useAppStore()

onMounted(() => {
  metrics.load()
  app.loadStats()
  metrics.start()
})

onBeforeUnmount(() => {
  metrics.stop()
})
</script>

<style scoped>
.metrics-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.stat-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
}
@media (max-width: 1100px) {
  .stat-row {
    grid-template-columns: repeat(2, 1fr);
  }
}

.stat-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 16px 20px;
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-md);
  box-shadow: var(--ev-shadow-sm);
}
.stat-num {
  font-size: var(--ev-fs-24);
  font-weight: 700;
  color: var(--ev-text);
}
.stat-num i {
  font-style: normal;
  font-size: var(--ev-fs-13);
  font-weight: 500;
  color: var(--ev-text-sub);
  margin-left: 3px;
}
.stat-label {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}

.chart-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}
@media (max-width: 1400px) {
  .chart-grid {
    grid-template-columns: 1fr;
  }
}

.card {
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-lg);
  padding: 14px 16px;
  box-shadow: var(--ev-shadow-md);
}
.card-title {
  font-size: var(--ev-fs-14);
  font-weight: 600;
  margin-bottom: 6px;
}

.sys-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px 24px;
  padding: 8px 0;
}
@media (max-width: 1100px) {
  .sys-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

.sys-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px;
  background: rgba(26, 34, 49, 0.55);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-sm);
}
.sys-key {
  font-size: var(--ev-fs-13);
  color: var(--ev-text-sub);
}
.sys-val {
  font-size: var(--ev-fs-13);
  color: var(--ev-text);
}
.sys-val.danger {
  color: var(--ev-danger);
}
</style>
