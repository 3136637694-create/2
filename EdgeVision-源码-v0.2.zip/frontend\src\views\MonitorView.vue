<template>
  <div class="monitor-page">
    <!-- ======== 视频画面卡片 ======== -->
    <div class="card video-card">
      <div class="card-head">
        <div class="head-left">
          <el-select
            v-model="camId"
            size="default"
            class="cam-select"
            placeholder="选择摄像头"
            @change="onSelectCamera"
          >
            <el-option
              v-for="c in cameraOptions"
              :key="c.id"
              :label="c.name"
              :value="c.id"
              :disabled="c.status !== 'online'"
            >
              <span class="opt-label">{{ c.name }}</span>
              <el-tag v-if="c.status !== 'online'" size="small" type="warning">断线</el-tag>
            </el-option>
          </el-select>
          <span v-if="currentCamera" class="cam-meta mono">
            {{ currentCamera.resolution }} · {{ currentCamera.location }}
          </span>
        </div>
        <div class="head-right">
          <el-switch v-model="monitor.showBoxes" size="small" active-text="检测框" />
          <el-switch v-model="monitor.showIds" size="small" active-text="ID" />
          <el-switch v-model="monitor.showTrails" size="small" active-text="轨迹" />
        </div>
      </div>

      <VideoCanvas
        :detections="monitor.detections"
        :track-history="monitor.trackHistory"
        :show-boxes="monitor.showBoxes"
        :show-ids="monitor.showIds"
        :show-trails="monitor.showTrails"
        :connected="monitor.connected"
        :no-frame="noFrame"
        :camera-name="currentCamera?.name ?? ''"
        :video-src="videoSrc"
      />

      <div class="card-foot">
        <span class="foot-item">
          <span class="dot" :class="liveClass" />{{ liveText }}
        </span>
        <span class="foot-item mono">目标 {{ targetCount }}</span>
        <span class="foot-item mono">FPS {{ latest?.fps?.toFixed(1) ?? '--' }}</span>
        <span class="foot-item mono">延迟 {{ latest?.e2eLatencyMs?.toFixed(0) ?? '--' }} ms</span>
        <span class="foot-item mono">队列 {{ latest?.queueUsage?.toFixed(0) ?? '--' }}%</span>
        <span class="foot-item mono">丢帧 {{ metrics.droppedFrames }}</span>
      </div>
    </div>

    <!-- ======== 实时数据面板 ======== -->
    <div class="panels">
      <div class="card panel">
        <div class="card-head">
          <span class="panel-title">实时检测结果</span>
          <span class="panel-sub mono">{{ monitor.detections.length }} 个目标</span>
        </div>
        <el-scrollbar max-height="300px">
          <div v-if="monitor.detections.length === 0" class="empty">
            <span>暂无检测目标</span>
          </div>
          <ul v-else class="det-list">
            <li v-for="d in monitor.detections" :key="d.id" class="det-item">
              <span class="cls-dot" :style="{ background: clsColor(d.cls) }" />
              <span class="det-cls">{{ clsText(d.cls) }}</span>
              <span class="mono det-id">ID {{ String(d.trackId).padStart(4, '0') }}</span>
              <span class="mono det-conf">{{ d.confidence.toFixed(2) }}</span>
            </li>
          </ul>
        </el-scrollbar>
      </div>

      <div class="card panel">
        <div class="card-head">
          <span class="panel-title">实时告警流</span>
          <el-button link type="primary" size="small" @click="router.push('/alerts')">查看全部</el-button>
        </div>
        <el-scrollbar max-height="300px">
          <div v-if="alerts.live.length === 0" class="empty">
            <span>暂无实时告警</span>
          </div>
          <ul v-else class="alert-list">
            <li v-for="e in alerts.live" :key="e.id" class="alert-item">
              <el-tag :type="levelType(e.level)" size="small" class="alert-tag">
                {{ levelText(e.level) }}
              </el-tag>
              <div class="alert-body">
                <p class="alert-msg">{{ e.message }}</p>
                <p class="alert-meta mono">{{ fmtClock(e.ts) }} · {{ e.cameraName }}</p>
              </div>
            </li>
          </ul>
        </el-scrollbar>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import VideoCanvas from '@/components/VideoCanvas.vue'
import { useCamerasStore } from '@/stores/cameras'
import { useMonitorStore } from '@/stores/monitor'
import { useAlertsStore } from '@/stores/alerts'
import { useMetricsStore } from '@/stores/metrics'
import { fmtClock } from '@/utils/format'
import { dataMode } from '@/config'
import type { DetClass, EventLevel } from '@/types'

const router = useRouter()
const cameras = useCamerasStore()
const monitor = useMonitorStore()
const alerts = useAlertsStore()
const metrics = useMetricsStore()

const camId = ref<number>(1)
const currentCamera = computed(() => cameras.byId(monitor.currentCameraId))
const cameraOptions = computed(() =>
  cameras.list.filter((c) => c.enabled),
)

const latest = computed(() => metrics.latest)

// 真实模式（API + 非模拟源）：接入后端 MJPEG 流作为画面底图
const videoSrc = computed(() => {
  const cam = currentCamera.value
  if (!cam) return undefined
  if (dataMode.value !== 'api' || cam.source.startsWith('sim:')) return undefined
  return `/stream/${cam.id}`
})

// 有视频流即为实时画面；否则以 WS 检测帧最后到达时间判断
const noFrame = computed(() => {
  if (videoSrc.value) return false
  return monitor.lastFrameAt === null || Date.now() - monitor.lastFrameAt > 4000
})
const liveClass = computed(() => (monitor.connected && !noFrame.value ? '' : 'offline'))
const liveText = computed(() => (monitor.connected && !noFrame.value ? '实时画面' : '等待连接'))
const targetCount = computed(() => monitor.detections.length)

function onSelectCamera(id: number): void {
  monitor.selectCamera(id)
}

const CLS_TEXT: Record<string, string> = { person: '人', vehicle: '车', object: '物' }
function clsText(cls: DetClass): string {
  return CLS_TEXT[cls] ?? cls
}
function clsColor(cls: DetClass): string {
  return { person: '#22D3EE', vehicle: '#FBBF24', object: '#34D399' }[cls] ?? '#22D3EE'
}
function levelType(lv: EventLevel): 'danger' | 'warning' | 'info' {
  return lv === 'critical' ? 'danger' : lv === 'warning' ? 'warning' : 'info'
}
function levelText(lv: EventLevel): string {
  return lv === 'critical' ? '严重' : lv === 'warning' ? '警告' : '提示'
}

onMounted(async () => {
  await cameras.load()
  if (cameraOptions.value.length) {
    const first = cameraOptions.value[0].id
    camId.value = first
    monitor.selectCamera(first)
  }
  monitor.start()
  metrics.start()
})

onBeforeUnmount(() => {
  monitor.stop()
  metrics.stop()
})
</script>

<style scoped>
.monitor-page {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.card {
  background: var(--ev-surface);
  border: 1px solid var(--ev-border);
  border-radius: var(--ev-radius-lg);
  padding: 14px 16px;
  box-shadow: var(--ev-shadow-md);
}

.card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  gap: 12px;
  flex-wrap: wrap;
}

.head-left {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}
.cam-select {
  width: 190px;
}
.opt-label {
  margin-right: 6px;
}
.cam-meta {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
  white-space: nowrap;
}

.head-right {
  display: flex;
  align-items: center;
  gap: 14px;
}

.card-foot {
  display: flex;
  align-items: center;
  gap: 18px;
  margin-top: 10px;
  padding: 8px 2px 0;
  border-top: 1px solid var(--ev-border);
}
.foot-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}
.foot-item .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--ev-success);
  box-shadow: 0 0 6px rgba(52, 211, 153, 0.8);
}
.foot-item .dot.offline {
  background: var(--ev-warning);
  box-shadow: 0 0 6px rgba(251, 191, 36, 0.7);
}

.panels {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
@media (max-width: 1100px) {
  .panels {
    grid-template-columns: 1fr;
  }
}

.panel-title {
  font-size: var(--ev-fs-14);
  font-weight: 600;
}
.panel-sub {
  font-size: var(--ev-fs-12);
  color: var(--ev-text-sub);
}

.empty {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 120px;
  color: var(--ev-text-sub);
  font-size: var(--ev-fs-13);
}

.det-list {
  list-style: none;
}
.det-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 6px;
  border-bottom: 1px solid rgba(30, 40, 56, 0.5);
  font-size: var(--ev-fs-13);
}
.det-item:last-child {
  border-bottom: none;
}
.cls-dot {
  width: 8px;
  height: 8px;
  border-radius: 2px;
  flex: none;
}
.det-cls {
  color: var(--ev-text);
  min-width: 20px;
}
.det-id {
  color: var(--ev-text-sub);
  flex: 1;
}
.det-conf {
  color: var(--ev-text-sub);
}

.alert-list {
  list-style: none;
}
.alert-item {
  display: flex;
  gap: 10px;
  padding: 9px 6px;
  border-bottom: 1px solid rgba(30, 40, 56, 0.5);
}
.alert-item:last-child {
  border-bottom: none;
}
.alert-tag {
  flex: none;
  margin-top: 1px;
}
.alert-body {
  min-width: 0;
}
.alert-msg {
  font-size: var(--ev-fs-13);
  color: var(--ev-text);
  line-height: 1.5;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.alert-meta {
  font-size: 11px;
  color: var(--ev-text-sub);
  margin-top: 2px;
}
</style>
