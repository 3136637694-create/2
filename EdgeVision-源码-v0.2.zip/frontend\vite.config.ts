import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      // 后端就绪后：/api -> FastAPI(8000)，/ws -> WebSocket 代理
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
      '/stream': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://127.0.0.1:8000',
        ws: true,
      },
    },
  },
  base: './',
  build: {
    outDir: 'dist',
  },
})
